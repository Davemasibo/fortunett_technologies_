<?php
header('Content-Type: application/json');
require_once '../../includes/config.php';

// Get parameters
// Get parameters
$identity = $_GET['identity'] ?? '';
$format = $_GET['format'] ?? 'json'; // json or rsc
$ip = $_SERVER['REMOTE_ADDR'];

if (!$identity) {
    if ($format === 'rsc') {
        echo ":log error \"Identity required for provisioning\";";
        exit;
    }
    echo json_encode(['status' => 'error', 'message' => 'Identity required']);
    exit;
}

try {
    // Generate a secure password for the admin user
    $adminPassword = bin2hex(random_bytes(8));

    // Check if exists
    $stmt = $pdo->prepare("SELECT id FROM mikrotik_routers WHERE name = ?");
    $stmt->execute([$identity]);
    $existing = $stmt->fetch();

    if ($existing) {
        // Update
        $update = $pdo->prepare("UPDATE mikrotik_routers SET ip_address = ?, status = 'online', last_connected = NOW() WHERE id = ?");
        $update->execute([$ip, $existing['id']]);
        $id = $existing['id'];
        
        // We might want to update password if we are re-provisioning, but let's keep it simple for now
        // Or actually, if we are generating a script, we SHOULD update the password in DB to match what we put in script
        if ($format === 'rsc') {
             $pdo->prepare("UPDATE mikrotik_routers SET password = ? WHERE id = ?")->execute([$adminPassword, $id]);
        }
    } else {
        // Insert
        // Use default API port 8728
        $insert = $pdo->prepare("INSERT INTO mikrotik_routers (name, ip_address, status, username, password, api_port, created_at, last_connected) VALUES (?, ?, 'online', 'fortunett_admin', ?, 8728, NOW(), NOW())");
        $insert->execute([$identity, $ip, $adminPassword]);
        $id = $pdo->lastInsertId();
    }

    if ($format === 'rsc') {
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="provision.rsc"');
        
        // Build the script
        $serverUrl = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']); // e.g. http://72.61.147.86/fortunett_technologies_/api/routers
        
        echo "# Fortunett Technologies Provisioning Script\n";
        echo "# Generated: " . date('Y-m-d H:i:s') . "\n\n";
        
        echo ":log info \"Starting Provisioning for $identity\";\n";
        echo "/system identity set name=\"$identity\";\n";
        
        // Create User
        echo "/user remove [find name=\"fortunett_admin\"];\n"; // Remove if exists to update pass
        echo "/user add name=\"fortunett_admin\" group=full password=\"$adminPassword\" comment=\"Managed by Fortunett\";\n";
        
        // Enable API
        echo "/ip service set api disabled=no port=8728;\n";
        
        // Add Scheduler for Heartbeat (every 5 minutes)
        echo "/system scheduler remove [find name=\"fortunett_heartbeat\"];\n";
        echo "/system scheduler add name=\"fortunett_heartbeat\" interval=5m on-event=\"/tool fetch mode=http url=\\\"$serverUrl/provision.php?identity=$identity\\\" keep-result=no check-certificate=no\" start-time=startup;\n";
        
        // Run Heartbeat Immediately to bind/register online status
        echo ":delay 2s;\n";
        echo "/tool fetch mode=http url=\"$serverUrl/provision.php?identity=$identity\" keep-result=no check-certificate=no;\n";
        
        echo ":log info \"Provisioning Complete\";\n";
        exit;
    }

    echo json_encode(['status' => 'success', 'id' => $id, 'message' => 'Router provisioned']);

} catch (Exception $e) {
    if ($format === 'rsc') {
        echo ":log error \"Provisioning Failed: " . addslashes($e->getMessage()) . "\";";
        exit;
    }
    file_put_contents(__DIR__ . '/../../logs/provision_error.log', $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
