<?php
// Database configuration
date_default_timezone_set('Africa/Nairobi');
// Database connection is handled in db_connect.php