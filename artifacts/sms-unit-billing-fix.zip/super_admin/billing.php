<?php
require_once __DIR__ . '/../includes/db_master.php';
require_once __DIR__ . '/includes/auth.php';
superAdminGuard();
require_once __DIR__ . '/../includes/platform_billing.php';
ensurePlatformBillingSchema($pdo);
ensureSmsInvoiceSchema($pdo);
foreach ($pdo->query("SELECT id FROM tenants WHERE status='trial'")->fetchAll(PDO::FETCH_COLUMN) as $trialId) {
    repairUnpaidTrialInvoices($pdo, (int)$trialId);
}

$statusFilter = $_GET['status'] ?? '';
$monthFilter  = $_GET['month']  ?? date('Y-m');
$search       = trim($_GET['q'] ?? '');
$invoiceId    = (int)($_GET['invoice'] ?? 0);

// The month filter defaulted to the current month with no way to escape it, so
// overdue invoices from previous months — precisely the ones keeping a tenant
// suspended — were invisible, and the Mark as Paid buttons on them unreachable.
// ?all=1 lists every period.
$showAllMonths = isset($_GET['all']) && $_GET['all'] !== '0';

// Single invoice detail
$invoiceDetail = null;
if ($invoiceId) {
    $stmt = $pdo->prepare("
        SELECT pi.*, t.company_name, t.subdomain, u.email AS admin_email
        FROM platform_invoices pi
        JOIN tenants t ON t.id = pi.tenant_id
        LEFT JOIN users u ON u.id = t.admin_user_id
        WHERE pi.id = ?
    ");
    $stmt->execute([$invoiceId]);
    $invoiceDetail = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Explicit invoice offsets share the payment allocation ledger with payouts.
$_SESSION['invoice_offset_csrf'] ??= bin2hex(random_bytes(32));
$offsetError = ''; $offsetAvailable = 0; $offsetRows = []; $offsetReady = false;
$offsetCutoff = (new DateTimeImmutable('now', new DateTimeZone('Africa/Nairobi')))->format('Y-m-d H:i:s');
if ($invoiceDetail) {
    try {
        require_once __DIR__ . '/../includes/disbursements.php';
        ensureDisbursementSchema($pdo);
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'invoice_offset') {
            if (!hash_equals($_SESSION['invoice_offset_csrf'], (string)($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Session expired. Reload and try again.');
            if (empty($_POST['confirm_offset'])) throw new InvalidArgumentException('Confirm the invoice deduction first.');
            $offsetId = recordDisbursement($pdo, (int)$invoiceDetail['tenant_id'], (int)$_SESSION['user_id'], [
                'cutoff'=>$_POST['cutoff'] ?? '', 'disbursed_at'=>$offsetCutoff,
                'cash_amount'=>'0', 'fees_amount'=>(string)$invoiceDetail['total_due'], 'platform_cost'=>'0',
                'notes'=>'Invoice settlement from collections', 'replace_manual'=>!empty($_POST['replace_manual']),
                'expected_gross'=>$_POST['expected_gross'] ?? '', 'expected_count'=>$_POST['expected_count'] ?? 0,
            ], $invoiceId);
            $_SESSION['invoice_offset_success'] = $invoiceId;
            header('Location: billing.php?invoice=' . $invoiceId); exit;
        }
        $offsetRows = disbursementPayments($pdo, (int)$invoiceDetail['tenant_id'], $offsetCutoff);
        $offsetAvailable = array_sum(array_map(fn($r)=>disbursementMoney((string)$r['amount']), $offsetRows)) / 100;
        $offsetReady = true;
    } catch (InvalidArgumentException $e) { $offsetError = $e->getMessage(); }
    catch (Throwable $e) { error_log('Invoice offset: ' . $e->getMessage()); $offsetError = 'Could not prepare or save the deduction. Reload to review the current balance.'; }
}

// Build invoice list query
$where  = [];
$params = [];

if (!$showAllMonths) {
    $where[]  = 'billing_period LIKE ?';
    $params[] = $monthFilter . '%';
}

if ($statusFilter) { $where[] = 'pi.status = ?'; $params[] = $statusFilter; }
if ($search) {
    $where[] = '(t.company_name LIKE ? OR t.subdomain LIKE ?)';
    $params  = array_merge($params, ["%$search%", "%$search%"]);
}

$invoices = $pdo->prepare("
    SELECT pi.*, t.company_name, t.subdomain
    FROM platform_invoices pi
    JOIN tenants t ON t.id = pi.tenant_id
    " . ($where ? 'WHERE ' . implode(' AND ', $where) : '') . "
    ORDER BY pi.billing_period DESC, pi.status ASC
    LIMIT 500
");
$invoices->execute($params);
$invoices = $invoices->fetchAll(PDO::FETCH_ASSOC);

// Summary for selected month
$billingPeriod = $monthFilter . '-01';
$summaryStmt = $pdo->prepare("
    SELECT
        COUNT(*) AS total_invoices,
        COALESCE(SUM(total_due), 0) AS total_billed,
        COALESCE(SUM(CASE WHEN status='paid' THEN total_due ELSE 0 END),0) AS total_collected,
        COALESCE(SUM(CASE WHEN status IN ('pending','overdue') THEN total_due ELSE 0 END),0) AS total_outstanding,
        SUM(CASE WHEN status='paid' THEN 1 ELSE 0 END) AS paid_count,
        SUM(CASE WHEN status='overdue' THEN 1 ELSE 0 END) AS overdue_count
    FROM platform_invoices
    WHERE billing_period = ?
");
$summaryStmt->execute([$billingPeriod]);
$summary = $summaryStmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Platform Billing — FortuNett Super Admin</title>
<link rel="icon" type="image/svg+xml" href="/favicon.svg">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<link href="css/dark.css?v=2" rel="stylesheet">
<link href="css/shell.css?v=2" rel="stylesheet">
<link href="css/admin.css?v=1" rel="stylesheet">
<script src="js/shell.js?v=2" defer></script>
<style>
:root{--sa-dark:#0f3460;--sa-mid:#16213e;--sa-accent:#e94560;--sidebar-w:240px;
      --neu-bg:#141414;--neu-surf:#1c1c1b;--neu-s2:#222221;--neu-border:rgba(255,255,255,.06);--neu-text:#e2e2e0;--neu-muted:#9a9a95;}
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:var(--neu-bg);display:flex;min-height:100vh;color:var(--neu-text);}
.sidebar{width:var(--sidebar-w);background:linear-gradient(180deg,#111827 0%,#16213e 55%,#0f3460 100%);color:#fff;flex-shrink:0;position:fixed;top:0;left:0;bottom:0;z-index:100;display:flex;flex-direction:column;box-shadow:4px 0 24px rgba(0,0,0,.5);border-right:1px solid rgba(255,255,255,.06);}
.sidebar-brand{padding:24px 20px 20px;border-bottom:1px solid rgba(255,255,255,.08);}
.sidebar-brand .badge-sa{background:linear-gradient(135deg,#e94560,#c0305a);color:#fff;font-size:10px;padding:2px 8px;border-radius:20px;letter-spacing:.8px;box-shadow:0 2px 8px rgba(233,69,96,.35);}
.sidebar-brand h2{font-size:16px;font-weight:700;margin-top:8px;color:#fff;}
.sidebar-brand p{font-size:11px;color:rgba(255,255,255,.5);margin-top:2px;}
.sidebar-menu{list-style:none;padding:12px 0;flex:1;overflow-y:auto;}
.sidebar-menu a{display:flex;align-items:center;gap:12px;padding:12px 20px;color:rgba(255,255,255,.72);text-decoration:none;font-size:14px;border-left:3px solid transparent;transition:all .2s;}
.sidebar-menu a:hover{background:rgba(255,255,255,.08);color:#fff;border-left-color:rgba(255,255,255,.25);}
.sidebar-menu a.active{background:rgba(255,255,255,.13);color:#fff;border-left-color:#e94560;}
.sidebar-menu a i{width:18px;text-align:center;font-size:15px;}
.sidebar-footer{padding:16px 20px;border-top:1px solid rgba(255,255,255,.08);font-size:12px;color:rgba(255,255,255,.45);}
.main{margin-left:var(--sidebar-w);flex:1;background:var(--neu-bg);}
.topbar{background:var(--neu-surf);padding:0 28px;height:60px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--neu-border);position:sticky;top:0;z-index:99;box-shadow:0 2px 20px rgba(0,0,0,.4);}
.topbar h1{font-size:18px;font-weight:700;color:#fff;}
.topbar .user-info{display:flex;align-items:center;gap:10px;font-size:14px;color:var(--neu-muted);}
.content{padding:28px;background:var(--neu-bg);}
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:22px;}
.stat-card{background:var(--neu-s2);border-radius:14px;padding:18px 20px;border:1px solid var(--neu-border);box-shadow:14px 14px 28px rgba(0,0,0,.5),-7px -7px 18px rgba(255,255,255,.035),0 0 0 1px var(--neu-border);transition:transform .2s,box-shadow .2s;}
.stat-card:hover{transform:translateY(-3px);box-shadow:18px 18px 36px rgba(0,0,0,.6),-8px -8px 22px rgba(255,255,255,.04),0 0 0 1px var(--neu-border);}
.stat-card .label{font-size:11px;font-weight:600;color:var(--neu-muted);text-transform:uppercase;letter-spacing:.5px;}
.stat-card .value{font-size:24px;font-weight:700;color:#fff;margin:6px 0 3px;}
.stat-card .sub{font-size:12px;color:var(--neu-muted);}
.filters-bar{background:var(--neu-s2);border-radius:12px;padding:14px 18px;margin-bottom:18px;display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;border:1px solid var(--neu-border);box-shadow:8px 8px 20px rgba(0,0,0,.4),-4px -4px 10px rgba(255,255,255,.025);}
.filters-bar input,.filters-bar select{padding:7px 12px;border:1px solid rgba(255,255,255,.08);border-radius:7px;font-size:13px;background:#1a1a19;color:var(--neu-text);box-shadow:inset 3px 3px 7px rgba(0,0,0,.3);}
.filters-bar input:focus,.filters-bar select:focus{outline:none;border-color:#3B6EA5;}
.btn-filter{padding:7px 16px;background:linear-gradient(135deg,#16213e,#0f3460);color:#fff;border:1px solid rgba(255,255,255,.12);border-radius:7px;font-size:13px;font-weight:600;cursor:pointer;transition:opacity .2s;}
.btn-filter:hover{opacity:.88;}
.card{background:var(--neu-s2);border-radius:14px;border:1px solid var(--neu-border);box-shadow:14px 14px 28px rgba(0,0,0,.5),-7px -7px 18px rgba(255,255,255,.035),0 0 0 1px var(--neu-border);}
table{width:100%;border-collapse:collapse;}
th{padding:10px 16px;font-size:12px;font-weight:600;text-transform:uppercase;color:var(--neu-muted);background:rgba(255,255,255,.04);text-align:left;border-bottom:1px solid var(--neu-border);}
td{padding:11px 16px;font-size:13px;color:var(--neu-text);border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle;}
tr:last-child td{border-bottom:none;}
tr:hover td{background:rgba(255,255,255,.035);}
.badge{display:inline-flex;align-items:center;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;}
.badge-paid{background:rgba(16,185,129,.18);color:#6ee7b7;}
.badge-pending{background:rgba(245,158,11,.18);color:#fcd34d;}
.badge-overdue{background:rgba(239,68,68,.18);color:#fca5a5;}
.badge-waived,.badge-cancelled{background:rgba(107,114,128,.18);color:#9ca3af;}
.btn-sm{padding:4px 10px;border-radius:6px;font-size:12px;font-weight:600;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:4px;transition:all .18s;}
.btn-paid{background:rgba(16,185,129,.15);color:#6ee7b7;border:1px solid rgba(16,185,129,.25);}
.btn-paid:hover{background:rgba(16,185,129,.28);color:#fff;}
.btn-view{background:rgba(255,255,255,.07);color:var(--neu-muted);border:1px solid var(--neu-border);}
.btn-view:hover{background:rgba(255,255,255,.13);color:var(--neu-text);}
.back-link{display:inline-flex;align-items:center;gap:6px;color:#93c5fd;text-decoration:none;font-size:14px;font-weight:600;margin-bottom:18px;}
.back-link:hover{color:#fff;}
.detail-panel{background:var(--neu-s2);border-radius:14px;padding:28px;border:1px solid var(--neu-border);box-shadow:14px 14px 28px rgba(0,0,0,.5),-7px -7px 18px rgba(255,255,255,.035),0 0 0 1px var(--neu-border);margin-bottom:24px;}
.detail-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:16px 0;}
.detail-item label{display:block;font-size:11px;font-weight:600;color:var(--neu-muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px;}
.detail-item span{font-size:14px;color:var(--neu-text);font-weight:500;}
.line-item{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--neu-border);font-size:14px;color:var(--neu-text);}
.line-total{display:flex;justify-content:space-between;padding:14px 0 0;font-size:16px;font-weight:700;color:#fff;}
table a{color:#3B6EA5;text-decoration:none;}
table a:hover{color:#93c5fd;}
@media(max-width:1100px){.stats-grid{grid-template-columns:repeat(2,1fr);}}
</style>
<link rel="stylesheet" href="/css/responsive-app.css?v=1">
<script src="/js/responsive-app.js?v=1" defer></script>
</head>
<body class="sa-shell">
<?php include __DIR__ . '/includes/navigation.php'; ?>

<div class="main">
    <div class="topbar">
        <p><a href="sms_usage.php">Tenant SMS usage</a></p>
<h1><?= $invoiceDetail ? 'Invoice Detail' : 'Platform Billing' ?></h1>
        <div style="display:flex;gap:10px;align-items:center;">
            <form method="POST" action="../api/super_admin/billing.php" style="display:inline;">
                <input type="hidden" name="action" value="generate_month">
                <input type="hidden" name="month" value="<?= $monthFilter ?>">
                <button type="submit" style="padding:8px 16px;background:var(--sa-dark);color:#fff;border:none;border-radius:7px;font-size:13px;font-weight:600;cursor:pointer;" onclick="return confirm('Generate invoices for all tenants for <?= $monthFilter ?>?')">
                    <i class="fas fa-bolt me-1"></i> Generate Invoices for <?= date('M Y', strtotime($monthFilter.'-01')) ?>
                </button>
            </form>
        </div>
    </div>
    <div class="content" id="sa-main-content">

    <?php if ($invoiceDetail): ?>
        <a href="billing.php?month=<?= $monthFilter ?>" class="back-link"><i class="fas fa-arrow-left"></i> Back to billing</a>
        <div class="detail-panel">
            <div class="inv-head">
                <div>
                    <div class="inv-eyebrow">Invoice</div>
                    <h2 class="inv-number"><?= htmlspecialchars($invoiceDetail['invoice_number']) ?></h2>
                    <div class="inv-sub">
                        <a href="tenants.php?id=<?= (int)$invoiceDetail['tenant_id'] ?>" style="color:#93c5fd;text-decoration:none;">
                            <strong><?= htmlspecialchars($invoiceDetail['company_name']) ?></strong>
                        </a>
                        &bull; <?= date('M Y', strtotime($invoiceDetail['billing_period'])) ?>
                    </div>
                </div>
                <span class="badge badge-<?= $invoiceDetail['status'] ?>" style="font-size:14px;padding:6px 16px;"><?= ucfirst($invoiceDetail['status']) ?></span>
            </div>

            <p><a href="sms_usage.php">View tenant SMS usage and charges</a></p>
            <!-- Line items -->
            <div class="inv-lines">
                <div class="line-item">
                    <span>PPPoE Users (<?= $invoiceDetail['pppoe_user_count'] ?> × KSH <?= number_format($invoiceDetail['pppoe_fee_per_user'], 2) ?>)</span>
                    <strong>KSH <?= number_format($invoiceDetail['pppoe_subtotal'], 2) ?></strong>
                </div>
                <div class="line-item">
                    <span>Hotspot Commission (<?= round($invoiceDetail['hotspot_commission_rate']*100, 2) ?>% × KSH <?= number_format($invoiceDetail['hotspot_collections'], 2) ?> collections)</span>
                    <strong>KSH <?= number_format($invoiceDetail['hotspot_commission'], 2) ?></strong>
                </div>
                <?php if ($invoiceDetail['base_fee'] > 0): ?>
                <div class="line-item">
                    <span><?= $invoiceDetail['router_count'] === null ? 'Monthly fee (previous billing)' : 'Monthly Router Fee ('.(int)$invoiceDetail['router_count'].' routers x KSH '.number_format($invoiceDetail['router_fee_per_router'],2).')' ?></span>
                    <strong>KSH <?= number_format($invoiceDetail['base_fee'], 2) ?></strong>
                </div>
                <?php endif; ?>
                <div class="line-item">
                    <span>Platform SMS (<?= (int)$invoiceDetail['sms_message_count'] ?> messages / <?= (int)$invoiceDetail['sms_units'] ?> units)</span>
                    <strong>KSH <?= number_format($invoiceDetail['sms_amount'], 2) ?></strong>
                </div>
                <div class="line-total">
                    <span>Total Due</span>
                    <span>KSH <?= number_format($invoiceDetail['total_due'], 2) ?></span>
                </div>
            </div>

            <div class="detail-grid">
                <div class="detail-item"><label>Billing Period</label><span><?= date('M Y', strtotime($invoiceDetail['billing_period'])) ?></span></div>
                <div class="detail-item"><label>Due Date</label><span><?= date('d M Y', strtotime($invoiceDetail['due_date'])) ?></span></div>
                <div class="detail-item"><label>Paid At</label><span><?= $invoiceDetail['paid_at'] ? date('d M Y H:i', strtotime($invoiceDetail['paid_at'])) : '—' ?></span></div>
                <div class="detail-item"><label>Transaction Ref</label><span><?= htmlspecialchars($invoiceDetail['transaction_ref'] ?? '—') ?></span></div>
                <div class="detail-item"><label>Admin Email</label><span><?= htmlspecialchars($invoiceDetail['admin_email'] ?? '—') ?></span></div>
            </div>

            <?php if ($offsetError): ?><p role="alert"><?= htmlspecialchars($offsetError) ?></p><?php endif; ?>
            <?php if (($_SESSION['invoice_offset_success'] ?? 0) === $invoiceId): unset($_SESSION['invoice_offset_success']); ?>
                <p role="status">Invoice settled from collections. The tenant's awaiting balance and payout history have been updated.</p>
            <?php endif; ?>
            <?php if ($invoiceDetail['payment_method'] === 'collections_offset'): ?>
                <p>Settled by deduction from collections; no separate cash payment was received.</p>
            <?php elseif ($offsetReady && (in_array($invoiceDetail['status'], ['pending','overdue'], true) || ($invoiceDetail['status'] === 'paid' && $invoiceDetail['payment_method'] === 'manual'))): ?>
            <form method="post" class="inv-actions" style="display:block;">
                <h3>Deduct invoice from collections</h3>
                <p>Awaiting payout: <strong>KSH <?= number_format($offsetAvailable, 2) ?></strong>.
                Invoice deduction: <strong>KSH <?= number_format($invoiceDetail['total_due'], 2) ?></strong>.
                Remaining after deduction: <strong>KSH <?= number_format($offsetAvailable - (float)$invoiceDetail['total_due'], 2) ?></strong>.</p>
                <p>This settles this invoice once using currently undistributed collections. It does not send money.</p>
                <input type="hidden" name="action" value="invoice_offset">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['invoice_offset_csrf']) ?>">
                <input type="hidden" name="cutoff" value="<?= htmlspecialchars($offsetCutoff) ?>">
                <input type="hidden" name="expected_gross" value="<?= number_format($offsetAvailable, 2, '.', '') ?>">
                <input type="hidden" name="expected_count" value="<?= count($offsetRows) ?>">
                <?php if ($invoiceDetail['status'] === 'paid'): ?>
                <p><label><input type="checkbox" name="replace_manual" value="1" required> The manual Paid entry was only a placeholder to prevent suspension. No separate payment was received for this invoice.</label></p>
                <?php endif; ?>
                <p><label><input type="checkbox" name="confirm_offset" value="1" required> Deduct KSH <?= number_format($invoiceDetail['total_due'], 2) ?> from this tenant's awaiting payout balance.</label></p>
                <button type="submit" class="btn-paid" <?= $offsetAvailable < (float)$invoiceDetail['total_due'] ? 'disabled' : '' ?>>Deduct invoice from collections</button>
                <?php if ($offsetAvailable < (float)$invoiceDetail['total_due']): ?><p>Insufficient undistributed collections to settle this invoice.</p><?php endif; ?>
            </form>
            <?php endif; ?>

            <?php if ($invoiceDetail['status'] !== 'paid'): ?>
            <div class="inv-actions">
                <div class="field">
                    <label for="txRef">Transaction Reference <span style="text-transform:none;letter-spacing:0;font-weight:500;">(optional)</span></label>
                    <input type="text" id="txRef" placeholder="e.g. QHK2YXM3Q1">
                </div>
                <button class="btn-paid" onclick="markPaid(<?= $invoiceDetail['id'] ?>, <?= $invoiceDetail['tenant_id'] ?>, this)">
                    <i class="fas fa-check"></i> Mark as Paid
                </button>
            </div>
            <p style="margin-top:12px;font-size:12.5px;color:var(--neu-muted);line-height:1.5;">
                Marking this paid clears it from the tenant's outstanding balance. If it is their
                last open invoice, a suspended tenant is reactivated immediately.
            </p>
            <?php endif; ?>
        </div>

    <?php else: ?>
        <!-- Summary stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="label">Total Billed</div>
                <div class="value">KSH <?= number_format($summary['total_billed'] ?? 0, 0) ?></div>
                <div class="sub"><?= $summary['total_invoices'] ?? 0 ?> invoices</div>
            </div>
            <div class="stat-card">
                <div class="label">Collected</div>
                <div class="value">KSH <?= number_format($summary['total_collected'] ?? 0, 0) ?></div>
                <div class="sub"><?= $summary['paid_count'] ?? 0 ?> paid</div>
            </div>
            <div class="stat-card">
                <div class="label">Outstanding</div>
                <div class="value" style="color:#fca5a5;">KSH <?= number_format($summary['total_outstanding'] ?? 0, 0) ?></div>
                <div class="sub"><?= $summary['overdue_count'] ?? 0 ?> overdue</div>
            </div>
            <div class="stat-card">
                <div class="label">Collection Rate</div>
                <div class="value"><?= ($summary['total_billed'] ?? 0) > 0 ? round(($summary['total_collected']/$summary['total_billed'])*100) : 0 ?>%</div>
                <div class="sub">of billed revenue</div>
            </div>
        </div>

        <!-- Filters -->
        <form method="GET" class="filters-bar">
            <div>
                <label style="font-size:12px;font-weight:600;color:var(--neu-muted);display:block;margin-bottom:4px;">Month</label>
                <input type="month" name="month" value="<?= $monthFilter ?>" <?= $showAllMonths ? 'disabled' : '' ?>>
            </div>
            <div>
                <label style="font-size:12px;font-weight:600;color:var(--neu-muted);display:block;margin-bottom:4px;">Period</label>
                <label style="display:flex;align-items:center;gap:6px;font-size:13px;color:var(--neu-border);padding:8px 0;white-space:nowrap;">
                    <input type="checkbox" name="all" value="1" <?= $showAllMonths ? 'checked' : '' ?>
                           onchange="this.form.submit()">
                    All months
                </label>
            </div>
            <div>
                <label style="font-size:12px;font-weight:600;color:var(--neu-muted);display:block;margin-bottom:4px;">Status</label>
                <select name="status">
                    <option value="">All</option>
                    <option value="pending" <?= $statusFilter==='pending'?'selected':'' ?>>Pending</option>
                    <option value="paid" <?= $statusFilter==='paid'?'selected':'' ?>>Paid</option>
                    <option value="overdue" <?= $statusFilter==='overdue'?'selected':'' ?>>Overdue</option>
                </select>
            </div>
            <div>
                <label style="font-size:12px;font-weight:600;color:var(--neu-muted);display:block;margin-bottom:4px;">Search</label>
                <input type="text" name="q" placeholder="Company or subdomain" value="<?= htmlspecialchars($search) ?>">
            </div>
            <button type="submit" class="btn-filter"><i class="fas fa-search me-1"></i> Filter</button>
            <a href="?all=1&status=pending" class="btn-filter"
               style="text-decoration:none;display:inline-flex;align-items:center;gap:6px;background:rgba(239,68,68,.15);color:#fca5a5;border:1px solid rgba(239,68,68,.25);"
               title="Every unpaid invoice across all billing periods — these are what keep tenants suspended">
                <i class="fas fa-triangle-exclamation"></i> All Outstanding
            </a>
        </form>

        <!-- Invoice table -->
        <div class="card">
            <table>
                <thead>
                    <tr><th>Invoice #</th><th>Tenant</th><th>Period</th><th>PPPoE</th><th>Hotspot</th><th>Total Due</th><th>Due Date</th><th>Status</th><th>Actions</th></tr>
                </thead>
                <tbody>
                <?php foreach ($invoices as $inv): ?>
                <tr>
                    <td style="font-family:monospace;"><?= htmlspecialchars($inv['invoice_number']) ?></td>
                    <td>
                        <strong><?= htmlspecialchars($inv['company_name']) ?></strong><br>
                        <small style="color:var(--neu-muted);"><?= $inv['subdomain'] ?></small>
                    </td>
                    <td><?= date('M Y', strtotime($inv['billing_period'])) ?></td>
                    <td><?= $inv['pppoe_user_count'] ?> users</td>
                    <td>KSH <?= number_format($inv['hotspot_collections'], 0) ?></td>
                    <td><strong>KSH <?= number_format($inv['total_due'], 2) ?></strong></td>
                    <td><?= date('d M Y', strtotime($inv['due_date'])) ?></td>
                    <td><span class="badge badge-<?= $inv['status'] ?>"><?= ucfirst($inv['status']) ?></span></td>
                    <td>
                        <a href="billing.php?invoice=<?= $inv['id'] ?>" class="btn-sm btn-view"><i class="fas fa-eye"></i> View</a>
                        <?php if ($inv['status'] !== 'paid'): ?>
                        <button class="btn-sm btn-paid" onclick="markPaid(<?= $inv['id'] ?>, <?= $inv['tenant_id'] ?>, this)"><i class="fas fa-check"></i> Paid</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($invoices)): ?>
                <tr><td colspan="9" style="text-align:center;padding:36px;color:var(--neu-muted);">No invoices found. Use "Generate Invoices" above to create them.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    </div>
</div>

<script>
function markPaid(invoiceId, tenantId, btn) {
    const refEl = document.getElementById('txRef');
    /* The list view has no reference field — prompt there so a reference can
       still be captured. It is the only audit trail tying the invoice to money. */
    let ref = refEl ? refEl.value.trim() : null;
    if (ref === null) {
        ref = prompt('Payment reference (M-Pesa code, bank ref, or note).\nLeave blank to auto-generate.', '');
        if (ref === null) return;
        ref = ref.trim();
    } else if (!confirm('Mark this invoice as paid?')) {
        return;
    }

    const original = btn ? btn.innerHTML : '';
    if (btn) { btn.disabled = true; btn.innerHTML = 'Saving…'; }

    fetch('../api/super_admin/tenants.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'mark_invoice_paid', tenant_id: tenantId, invoice_id: invoiceId, transaction_ref: ref })
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) { location.reload(); return; }
        if (btn) { btn.disabled = false; btn.innerHTML = original; }
        alert(d.message || 'Failed');
    })
    .catch(() => {
        if (btn) { btn.disabled = false; btn.innerHTML = original; }
        alert('Network error.');
    });
}
</script>
</body>
</html>
