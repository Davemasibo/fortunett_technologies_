<?php
require_once __DIR__ . '/includes/db_master.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/payment_admin.php';
redirectIfNotLoggedIn();

// Get current user's tenant_id
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT tenant_id FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$tenant_id = $stmt->fetchColumn();

// ── CSV Export ────────────────────────────────────────────────────────────────
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $exp_from   = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
    $exp_to     = $_GET['date_to']   ?? date('Y-m-d');
    $exp_method = $_GET['method']    ?? '';
    $exp_search = $_GET['search']    ?? '';
    $exp_status = $_GET['status']    ?? '';

    $q = "SELECT p.*, c.full_name, c.phone, c.account_number
          FROM payments p
          LEFT JOIN clients c ON p.client_id = c.id
          WHERE p.tenant_id = ? AND DATE(p.payment_date) BETWEEN ? AND ?";
    $qp = [$tenant_id, $exp_from, $exp_to];

    if ($exp_search) {
        $q  .= " AND (c.full_name LIKE ? OR c.phone LIKE ? OR p.transaction_id LIKE ? OR p.checkout_request_id LIKE ?)";
        $t   = "%$exp_search%";
        $qp  = array_merge($qp, [$t, $t, $t, $t]);
    }
    if ($exp_method && $exp_method !== 'All Methods') {
        $mv  = strtolower($exp_method) === 'm-pesa' ? 'mpesa' : strtolower($exp_method);
        if ($mv === 'mpesa') $q .= " AND p.payment_method IN ('mpesa','mpesa_stk','mpesa_paybill','mpesa_c2b')";
        else { $q .= " AND p.payment_method = ?"; $qp[] = $mv; }
    }
    if ($exp_status && $exp_status !== 'All') {
        $q  .= " AND p.status = ?"; $qp[] = strtolower($exp_status);
    }
    $q .= " ORDER BY p.payment_date DESC";

    $s = $pdo->prepare($q); $s->execute($qp);
    $rows = $s->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="payments_export_' . $exp_from . '_to_' . $exp_to . '.csv"');
    $out = fopen('php://output', 'w');
    // Settlement columns are exported too, so an ISP reconciling against their
    // own M-Pesa statement can tell at a glance which rows should appear in it
    // (Paid to you directly) and which never will (collected by the FortuNett
    // till and owed to them instead).
    fputcsv($out, ['ID','Customer','Phone','Account No','Amount (KES)','Method','Transaction ID','Status','Settlement','Disbursed On','Date','Notes']);
    foreach ($rows as $r) {
        $rColl = $r['collection_type'] ?? 'direct';
        $rRel  = $r['released_at'] ?? null;
        $rSettle = in_array(($r['status'] ?? ''), ['failed','cancelled'], true)
            ? 'No funds moved'
            : (($r['status'] ?? '') !== 'completed' ? 'Not yet received' : ($rColl === 'platform'
                ? ($rRel ? 'Settled (payouts / deductions)' : 'Awaiting disbursement')
                : 'Paid to you directly'));
        fputcsv($out, [
            $r['id'],
            $r['full_name']     ?? 'Unknown',
            $r['phone']         ?? '',
            $r['account_number']?? '',
            number_format($r['amount'] ?? 0, 2, '.', ''),
            strtoupper($r['payment_method'] ?? ''),
            $r['transaction_id']?? '',
            $r['status']        ?? '',
            $rSettle,
            $rRel               ?? '',
            $r['payment_date']  ?? '',
            $r['notes']         ?? '',
        ]);
    }
    fclose($out);
    exit;
}

// Calculate stats from payments table
try {
    // Total Revenue Today
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM payments WHERE DATE(payment_date) = CURDATE() AND status = 'completed' AND tenant_id = ?");
    $stmt->execute([$tenant_id]);
    $revenue_today = (float)$stmt->fetchColumn();
    
    // Confirmed Transactions (overall)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM payments WHERE status = 'completed' AND tenant_id = ?");
    $stmt->execute([$tenant_id]);
    $confirmed_transactions = (int)$stmt->fetchColumn();
    
    // Pending Payments
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM payments WHERE status = 'pending' AND tenant_id = ?");
    $stmt->execute([$tenant_id]);
    $pending_payments = (int)$stmt->fetchColumn();
    
    // Failed Transactions
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM payments WHERE status = 'failed' AND tenant_id = ?");
    $stmt->execute([$tenant_id]);
    $failed_transactions = (int)$stmt->fetchColumn();
    
} catch (Exception $e) {
    $revenue_today = 0;
    $confirmed_transactions = 0;
    $pending_payments = 0;
    $failed_transactions = 0;
}

// ── Settlement position ──────────────────────────────────────────────────────
// An ISP has two very different piles of money and only ever saw one number.
// `direct`   — the customer paid the ISP's own paybill/till. Already in the bank.
// `platform` — the customer paid the FortuNett shared till. FortuNett is holding
//              it and owes the ISP a payout; released_at says whether it has
//              been sent. Showing that as anything resembling "direct" hides a
//              debt owed to the ISP, which is what this page used to do.
require_once __DIR__ . '/includes/c2b_registration.php';

$settlement = [
    'direct_amount'     => 0.0, 'direct_count'     => 0,
    'awaiting_amount'   => 0.0, 'awaiting_count'   => 0,
    'disbursed_amount'  => 0.0, 'disbursed_count'  => 0,
];
// released_at is created lazily by billing.php on deployments that predate the
// disbursement feature. An ISP can reach this page without ever opening billing,
// so create it here too rather than letting the whole panel read zero.
try { $pdo->exec("ALTER TABLE payments ADD COLUMN released_at DATETIME DEFAULT NULL"); } catch (Exception $e) {}

try {
    require_once __DIR__ . '/includes/disbursements.php';
    ensureDisbursementBalance($pdo);
    $sSt = $pdo->prepare("
        SELECT
            COALESCE(SUM(CASE WHEN collection_type <> 'platform' THEN amount END), 0)                          AS direct_amount,
            COUNT(CASE WHEN collection_type <> 'platform' THEN 1 END)                                          AS direct_count,
            COALESCE(SUM(CASE WHEN collection_type = 'platform' AND released_at IS NULL THEN amount - disbursed_amount END), 0)    AS awaiting_amount,
            COUNT(CASE WHEN collection_type = 'platform' AND released_at IS NULL THEN 1 END)                    AS awaiting_count,
            COALESCE(SUM(CASE WHEN collection_type = 'platform' THEN CASE WHEN released_at IS NOT NULL THEN amount ELSE disbursed_amount END END), 0) AS disbursed_amount,
            COUNT(CASE WHEN collection_type = 'platform' AND (released_at IS NOT NULL OR disbursed_amount > 0) THEN 1 END) AS disbursed_count
        FROM payments
        WHERE tenant_id = ? AND status = 'completed'
    ");
    $sSt->execute([$tenant_id]);
    $settlement = $sSt->fetch(PDO::FETCH_ASSOC) ?: $settlement;
} catch (Exception $e) {
    // released_at is added lazily by billing.php on older deployments
}

// Is auto-activation actually on for payments made straight to this ISP?
$c2bStatus = tenantC2BStatus($pdo, (int)$tenant_id);

// Direct payments that arrived but matched no customer — money sitting unclaimed.
require_once __DIR__ . '/includes/unmatched_payments.php';
$unmatchedCount = count_unmatched_payments($pdo, (int)$tenant_id);

// Get filters
$search = $_GET['search'] ?? '';
$date_from = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
$date_to = $_GET['date_to'] ?? date('Y-m-d');
$filter_method = $_GET['method'] ?? '';

// Build Query - Fetch all payments including failed/cancelled (join mpesa_transactions for actual result)
//
// is_manual drives the Edit and Delete items in the row menu. Only a
// hand-entered payment may be changed -- a row that came from Safaricom is the
// record of money that actually moved -- and the menu is built from the same
// test the API enforces, so the UI never offers a button that is certain to
// fail. manuallyRecordedSql() is the single definition of "hand-entered".
$query = "
    SELECT p.*, c.full_name, c.phone,
           mt.result_code AS mpesa_result_code,
           mt.result_desc AS mpesa_result_desc,
           " . manuallyRecordedSql('p') . " AS is_manual
    FROM payments p
    LEFT JOIN clients c ON p.client_id = c.id
    LEFT JOIN mpesa_transactions mt ON mt.id = (SELECT MAX(mx.id) FROM mpesa_transactions mx WHERE mx.tenant_id=p.tenant_id AND mx.client_id=p.client_id AND (mx.checkout_request_id=p.transaction_id OR mx.checkout_request_id=p.checkout_request_id OR mx.mpesa_receipt_number=p.transaction_id))
    WHERE p.tenant_id = ? AND DATE(p.payment_date) BETWEEN ? AND ?
";
$params = [$tenant_id, $date_from, $date_to];

if ($search) {
    $query .= " AND (c.full_name LIKE ? OR c.phone LIKE ? OR p.transaction_id LIKE ? OR p.checkout_request_id LIKE ?)";
    $term = "%$search%";
    $params = array_merge($params, [$term, $term, $term, $term]);
}

if ($filter_method && $filter_method !== 'All Methods') {
    // Clean string (e.g. from UI 'Cash', 'M-Pesa')
    $filterVal = strtolower($filter_method);
    if ($filterVal == 'm-pesa') $filterVal = 'mpesa';
    if ($filterVal === 'mpesa') $query .= " AND p.payment_method IN ('mpesa','mpesa_stk','mpesa_paybill','mpesa_c2b')";
    else { $query .= " AND p.payment_method = ?"; $params[] = $filterVal; }
}

$query .= " ORDER BY p.payment_date DESC, p.created_at DESC LIMIT 100";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $transactions = [];
}

// Get Clients for Dropdown
try {
    $stmt = $pdo->prepare("SELECT id, full_name, phone, subscription_plan FROM clients WHERE tenant_id = ? ORDER BY full_name ASC");
    $stmt->execute([$tenant_id]);
    $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $clients = [];
}

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<style>
    .main-content-wrapper { background: #141414 !important; }
    .payments-container { padding: 24px 32px; max-width: 1400px; margin: 0 auto;
    }
    .payments-title { font-size: 28px; font-weight: 600; color: #e2e2e0; margin: 0 0 4px 0; }
    .payments-subtitle { font-size: 14px; color: #9a9a95; margin: 0 0 24px 0; }

    /* Stats */
    .stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 24px; }
    .stat-card { background: #222221; border-radius: 12px; padding: 20px; border: 1px solid rgba(255,255,255,.06); box-shadow: 8px 8px 20px rgba(0,0,0,.4), -4px -4px 10px rgba(255,255,255,.03); }
    .stat-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; }
    .stat-icon { width: 40px; height: 40px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; }
    .stat-icon.revenue   { background: rgba(16,185,129,.15);  color: #6ee7b7; }
    .stat-icon.confirmed { background: rgba(59,130,246,.15);  color: #93c5fd; }
    .stat-icon.pending   { background: rgba(245,158,11,.15);  color: #fcd34d; }
    .stat-icon.failed    { background: rgba(239,68,68,.15);   color: #fca5a5; }
    .stat-value { font-size: 28px; font-weight: 700; color: #fff; margin-bottom: 4px; }
    .stat-label { font-size: 13px; color: #9a9a95; font-weight: 500; }
    .stat-change { font-size: 12px; margin-top: 8px; }
    .stat-change.positive { color: #34d399; }

    /* Filters */
    .filters-section { background: #222221; border-radius: 12px; padding: 20px 24px; margin-bottom: 20px; border: 1px solid rgba(255,255,255,.06); }
    .filters-title { font-size: 16px; font-weight: 600; color: #e2e2e0; margin-bottom: 16px; }
    .filters-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr auto auto; gap: 12px; align-items: end; }
    .filter-group { display: flex; flex-direction: column; gap: 6px; }
    .filter-label { font-size: 12px; font-weight: 500; color: #9a9a95; }
    .filter-input, .filter-select {
        padding: 8px 12px; border: 1px solid rgba(255,255,255,.08); border-radius: 6px;
        font-size: 14px; background: #1a1a19; color: #e2e2e0;
        box-shadow: inset 2px 2px 5px rgba(0,0,0,.4), inset -1px -1px 3px rgba(255,255,255,.04);
    }
    .filter-btn { padding: 8px 16px; border-radius: 6px; font-size: 14px; font-weight: 500; cursor: pointer; border: 1px solid rgba(255,255,255,.08); background: rgba(255,255,255,.05); color: #e2e2e0; }
    .filter-btn.primary { background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-color) 100%); color: white; border: none; }

    /* Transactions table */
    .transactions-section { background: #222221; border-radius: 12px; border: 1px solid rgba(255,255,255,.06); overflow: hidden; box-shadow: 8px 8px 20px rgba(0,0,0,.4), -4px -4px 10px rgba(255,255,255,.03); }
    .transactions-header { padding: 16px 24px; border-bottom: 1px solid rgba(255,255,255,.07); display: flex; align-items: center; justify-content: space-between; }
    .transactions-title { font-size: 16px; font-weight: 600; color: #e2e2e0; }
    .transactions-actions { display: flex; gap: 8px; }
    .action-link { padding: 6px 12px; border-radius: 6px; font-size: 13px; text-decoration: none; display: flex; align-items: center; gap: 6px; }
    .action-link.refresh { color: #9a9a95; }
    .action-link.manual { background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-color) 100%); color: white; }
    .transactions-table { width: 100%; border-collapse: collapse; }
    .transactions-table thead { background: rgba(255,255,255,.04); border-bottom: 1px solid rgba(255,255,255,.07); }
    .transactions-table th { padding: 12px 16px; text-align: left; font-size: 11px; font-weight: 600; color: #9a9a95; text-transform: uppercase; letter-spacing: 0.05em; }
    .transactions-table td { padding: 14px 16px; border-bottom: 1px solid rgba(255,255,255,.05); font-size: 14px; color: #e2e2e0; }
    .transactions-table tbody tr:hover { background: rgba(255,255,255,.04); }
    .customer-name { font-weight: 500; color: #fff; }
    .customer-id   { font-size: 12px; color: #9a9a95; }
    .transaction-id { font-family: monospace; font-size: 13px; color: #9a9a95; }

    /* Method badges */
    .payment-method { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 500; }
    .payment-method.mpesa { background: rgba(16,185,129,.15); color: #6ee7b7; }
    .payment-method.cash  { background: rgba(59,130,246,.15);  color: #93c5fd; }

    /* Status badges */
    .status-badge { padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 500; display: inline-flex; align-items: center; gap: 6px; }
    .status-badge.completed { background: rgba(16,185,129,.15);  color: #6ee7b7; border: 1px solid rgba(16,185,129,.25); }
    .status-badge.pending   { background: rgba(245,158,11,.15);  color: #fcd34d; border: 1px solid rgba(245,158,11,.25); }
    .status-badge.failed    { background: rgba(239,68,68,.15);   color: #fca5a5; border: 1px solid rgba(239,68,68,.25); }

    /* Three-dot dropdown */
    .dot-menu-wrap { position: relative; display: inline-block; }
    .dot-menu-btn { width: 32px; height: 32px; border-radius: 8px; border: 1px solid rgba(255,255,255,.08); background: rgba(255,255,255,.05); color: #9a9a95; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 15px; transition: all .18s; }
    .dot-menu-btn:hover { background: var(--primary-color,#3B6EA5); border-color: transparent; color: #fff; }
    .dot-menu-dropdown { display: none; position: absolute; right: 0; top: 36px; background: #2a2a29; border: 1px solid rgba(255,255,255,.1); border-radius: 10px; min-width: 190px; box-shadow: 0 8px 32px rgba(0,0,0,.7); z-index: 500; overflow: hidden; }
    .dot-menu-dropdown.open { display: block; }
    .dot-menu-item { display: flex; align-items: center; gap: 10px; padding: 10px 14px; font-size: 13px; color: #d4d4d2; cursor: pointer; border: none; background: none; width: 100%; text-align: left; transition: background .15s; }
    .dot-menu-item:hover { background: rgba(255,255,255,.07); color: #fff; }
    .dot-menu-item i { width: 16px; text-align: center; color: rgba(255,255,255,.45); flex-shrink: 0; }
    .dot-menu-item:hover i { color: var(--primary-light, #93c5fd); }
    .dot-menu-item.sep { border-top: 1px solid rgba(255,255,255,.07); }
    .dot-menu-item.danger { color: #fca5a5; }
    .dot-menu-item.danger:hover { background: rgba(239,68,68,.12); color: #fecaca; }
    .dot-menu-item.danger i { color: rgba(252,165,165,.6); }
    .dot-menu-item.danger:hover i { color: #fca5a5; }

    /* Live duplicate-reference feedback. The write path enforces the rule
       regardless; this only saves the operator from filling in the rest of the
       form before being told the code is taken. */
    .ref-hint { font-size: 12px; margin-top: 6px; line-height: 1.45; display: none; }
    .ref-hint.show { display: block; }
    .ref-hint.bad { color: #fca5a5; }
    .ref-hint.good { color: #6ee7b7; }
    .ref-hint.checking { color: rgba(255,255,255,.35); }
    .pay-input.ref-bad { border-color: rgba(239,68,68,.5) !important; }

    /* Transaction filter tabs */
    .tx-tabs { display: flex; gap: 6px; padding: 14px 24px 0; flex-wrap: wrap; }
    .tx-tab { padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; border: 1px solid rgba(255,255,255,.08); background: rgba(255,255,255,.04); color: rgba(255,255,255,.45); cursor: pointer; transition: all .2s; display: flex; align-items: center; gap: 6px; }
    .tx-tab:hover { color: rgba(255,255,255,.75); background: rgba(255,255,255,.07); }
    .tx-tab.active { background: rgba(255,255,255,.1); color: #fff; border-color: rgba(255,255,255,.2); }
    .tx-tab .tc { font-size: 11px; padding: 1px 6px; border-radius: 8px; background: rgba(255,255,255,.1); min-width: 18px; text-align: center; }
    .tx-tab.active .tc { background: rgba(255,255,255,.2); }
    .tx-tabs .tx-tab-sep { width: 1px; align-self: stretch; margin: 2px 6px; background: rgba(255,255,255,.1); }

    /* Settlement position — where each shilling actually is */
    .settle-strip { display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 14px; margin-bottom: 18px; }
    .settle-card { background: #1e1e1d; border: 1px solid rgba(255,255,255,.07); border-left-width: 3px; border-radius: 12px; padding: 16px 18px; }
    .settle-card.direct    { border-left-color: #10b981; }
    .settle-card.awaiting  { border-left-color: #f59e0b; }
    .settle-card.disbursed { border-left-color: #3b82f6; }
    .settle-label { font-size: 12px; font-weight: 600; color: rgba(255,255,255,.55); display: flex; align-items: center; gap: 7px; }
    .settle-card.direct    .settle-label i { color: #6ee7b7; }
    .settle-card.awaiting  .settle-label i { color: #fcd34d; }
    .settle-card.disbursed .settle-label i { color: #93c5fd; }
    .settle-value { font-size: 21px; font-weight: 700; color: #e2e2e0; margin: 8px 0 5px; }
    .settle-sub { font-size: 11px; color: rgba(255,255,255,.38); line-height: 1.5; }

    /* Auto-activation / unmatched banners */
    .autoact-banner { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; padding: 14px 18px; border-radius: 12px; margin-bottom: 18px; font-size: 13px; }
    .autoact-banner.on  { background: rgba(16,185,129,.08); border: 1px solid rgba(16,185,129,.22); color: #6ee7b7; }
    .autoact-banner.off { background: rgba(245,158,11,.08); border: 1px solid rgba(245,158,11,.22); color: #fcd34d; }
    .autoact-banner > i { font-size: 19px; flex-shrink: 0; }
    .autoact-banner strong { color: #fff; font-size: 14px; }

    /* Per-payment settlement chip */
    .route-chip { display: inline-flex; align-items: center; gap: 6px; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; white-space: nowrap; }
    .route-chip .dot { width: 5px; height: 5px; border-radius: 50%; flex-shrink: 0; }
    .route-chip.direct    { background: rgba(16,185,129,.13); color: #6ee7b7; border: 1px solid rgba(16,185,129,.25); }
    .route-chip.direct .dot { background: #10b981; }
    .route-chip.awaiting  { background: rgba(245,158,11,.13); color: #fcd34d; border: 1px solid rgba(245,158,11,.25); }
    .route-chip.awaiting .dot { background: #f59e0b; animation: pulse-dot 1.5s ease infinite; }
    .route-chip.disbursed { background: rgba(59,130,246,.13); color: #93c5fd; border: 1px solid rgba(59,130,246,.25); }
    .route-chip.disbursed .dot { background: #3b82f6; }
    .route-chip.none      { background: rgba(255,255,255,.05); color: rgba(255,255,255,.35); border: 1px solid rgba(255,255,255,.08); }
    .route-chip.none .dot { background: rgba(255,255,255,.25); }
    .route-sub { font-size: 10px; color: rgba(255,255,255,.3); margin-top: 3px; }

    /* Unmatched payment rows */
    .um-row { background: rgba(255,255,255,.03); border: 1px solid rgba(255,255,255,.07); border-radius: 10px; padding: 14px 16px; margin-bottom: 12px; }
    .um-head { display: flex; justify-content: space-between; gap: 12px; flex-wrap: wrap; align-items: baseline; }
    .um-amt { font-size: 17px; font-weight: 700; color: #e2e2e0; }
    .um-meta { font-size: 11px; color: rgba(255,255,255,.38); line-height: 1.7; margin-top: 4px; }
    .um-meta code { font-family: monospace; color: #cbd5e1; }
    .um-sugg { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 8px 10px; margin-top: 8px; background: rgba(255,255,255,.03); border: 1px solid rgba(255,255,255,.06); border-radius: 8px; }
    .um-sugg-btn { padding: 5px 12px; border: none; border-radius: 6px; font-size: 12px; font-weight: 600; cursor: pointer; background: linear-gradient(135deg,var(--primary-dark,#2C5282) 0%,var(--primary-color,#3B6EA5) 100%); color: #fff; }
    .um-sugg-btn[disabled] { opacity: .55; cursor: default; }

    /* Payment modal shared input style */
    .pay-input {
        width:100%;padding:10px 12px;border:1px solid rgba(255,255,255,.08);border-radius:8px;
        font-size:14px;background:#1a1a19;color:#e2e2e0;box-sizing:border-box;
        box-shadow:inset 3px 3px 7px rgba(0,0,0,.35),inset -1px -1px 3px rgba(255,255,255,.03);
        transition:border-color .2s;font-family:inherit;
    }
    .pay-input:focus { outline:none;border-color:var(--primary-color,#3B6EA5);box-shadow:inset 3px 3px 7px rgba(0,0,0,.35),0 0 0 3px rgba(59,110,165,.18); }
    .pay-input::placeholder { color:rgba(255,255,255,.25); }
    .pay-input option { background:#1a1a19;color:#e2e2e0; }
    .pay-method-label {
        display:flex;align-items:center;gap:8px;cursor:pointer;
        padding:10px 14px;border:1px solid rgba(255,255,255,.1);border-radius:8px;
        flex:1;justify-content:center;background:rgba(255,255,255,.04);
        font-size:14px;font-weight:500;color:rgba(255,255,255,.6);transition:all .2s;
    }
    .pay-method-label.pay-method-active {
        border:2px solid var(--primary-color,#3B6EA5);background:rgba(59,110,165,.15);
        color:var(--primary-light,#93c5fd);font-weight:600;
    }
    .pay-submit-btn {
        width:100%;padding:13px;
        background:linear-gradient(135deg,var(--primary-dark,#2C5282) 0%,var(--primary-color,#3B6EA5) 100%);
        color:white;border:none;border-radius:8px;cursor:pointer;
        font-weight:700;font-size:15px;letter-spacing:.02em;transition:opacity .2s,transform .15s;
    }
    .pay-submit-btn:hover { opacity:.9;transform:translateY(-1px); }
    /* viewModal dark content styles */
    .vm-grid { display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px; }
    .vm-label { font-size:11px;font-weight:700;color:rgba(255,255,255,.35);text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px; }
    .vm-value { font-size:15px;font-weight:600;color:#e2e2e0; }
    .vm-sub { font-size:13px;color:rgba(255,255,255,.4); }
    .vm-detail-box { background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:16px;margin-bottom:20px; }
    .vm-row { display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;font-size:13px; }
    .vm-row:last-child { margin-bottom:0; }
    .vm-row-label { color:rgba(255,255,255,.4); }
    .vm-row-val { font-weight:600;color:#e2e2e0;font-family:monospace; }
    /* Sandbox warning banner */
    #sandboxBanner { display:none;margin-bottom:14px;padding:11px 14px;background:rgba(251,191,36,.1);border:1px solid rgba(251,191,36,.3);border-radius:8px;font-size:13px;color:#fcd34d; }

    .transactions-section { width: 100%; }
    .table-scroll { width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch; }
    .transactions-table { width: 100%; min-width: 700px; }

    @media (max-width: 1024px) { .filters-grid { grid-template-columns: 1fr 1fr; } }
    @media (max-width: 640px) { .payments-container { padding: 16px; } .filters-grid { grid-template-columns: 1fr; } }

    #paymentForm button[type="submit"]:hover { filter: brightness(110%); transform: translateY(-1px); box-shadow: 0 4px 12px rgba(0,0,0,.5); }
</style>

<div class="main-content-wrapper">
    <div class="payments-container">
        <!-- Header -->
        <div class="payments-header">
            <h1 class="payments-title">Payment Processing</h1>
            <p class="payments-subtitle">Manage M-Pesa transactions, manual payments, and financial reconciliation</p>
        </div>

        <!-- Stats Cards -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon revenue">
                        <i class="fas fa-chart-line"></i>
                    </div>
                </div>
                <div class="stat-value">KSh <?php echo number_format($revenue_today, 2); ?></div>
                <div class="stat-label">Total Revenue Today</div>
                <div class="stat-change">
                    <span class="metric-period">Total Today</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon confirmed">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
                <div class="stat-value"><?php echo $confirmed_transactions; ?></div>
                <div class="stat-label">Confirmed Transactions</div>
                <div class="stat-change">
                    <span class="metric-period">Total Today</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon pending">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
                <div class="stat-value"><?php echo $pending_payments; ?></div>
                <div class="stat-label">Pending Payments</div>
                <div class="stat-change">
                    <span class="metric-period">Awaiting Completion</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon failed">
                        <i class="fas fa-times-circle"></i>
                    </div>
                </div>
                <div class="stat-value"><?php echo $failed_transactions; ?></div>
                <div class="stat-label">Failed Transactions</div>
                <div class="stat-change">
                    <span class="metric-period">Needs Attention</span>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="filters-section">
            <h3 class="filters-title">Filter Transactions</h3>
            <form method="GET" class="filters-grid">
                <div class="filter-group">
                    <label class="filter-label">Search</label>
                    <input type="text" name="search" class="filter-input" placeholder="Name, Phone, Trans ID..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="filter-group">
                    <label class="filter-label">Date From</label>
                    <input type="date" name="date_from" class="filter-input" value="<?php echo htmlspecialchars($date_from); ?>">
                </div>
                <div class="filter-group">
                    <label class="filter-label">Date To</label>
                    <input type="date" name="date_to" class="filter-input" value="<?php echo htmlspecialchars($date_to); ?>">
                </div>
                <div class="filter-group">
                    <label class="filter-label">Payment Method</label>
                    <select name="method" class="filter-select">
                        <option>All Methods</option>
                        <option <?php echo $filter_method == 'M-Pesa' ? 'selected' : ''; ?>>M-Pesa</option>
                        <option <?php echo $filter_method == 'Cash' ? 'selected' : ''; ?>>Cash</option>
                    </select>
                </div>
                <button type="button" class="filter-btn" onclick="window.location.href='payments.php'">Reset Filters</button>
                <button type="submit" class="filter-btn primary">Apply Filters</button>
            </form>
        </div>

        <!-- ── Where your money is ──────────────────────────────────────────
             Two piles, never one: what customers paid you directly, and what
             FortuNett collected on your behalf and still owes you. -->
        <div class="settle-strip">
            <div class="settle-card direct">
                <div class="settle-label"><i class="fas fa-building-columns"></i> Paid to you directly</div>
                <div class="settle-value">KES <?php echo number_format((float)$settlement['direct_amount'], 2); ?></div>
                <div class="settle-sub"><?php echo (int)$settlement['direct_count']; ?> payment(s) — already in your own M-Pesa account</div>
            </div>
            <div class="settle-card awaiting">
                <div class="settle-label"><i class="fas fa-clock"></i> Awaiting disbursement</div>
                <div class="settle-value">KES <?php echo number_format((float)$settlement['awaiting_amount'], 2); ?></div>
                <div class="settle-sub"><?php echo (int)$settlement['awaiting_count']; ?> payment(s) — collected by the FortuNett till, owed to you</div>
            </div>
            <div class="settle-card disbursed">
                <div class="settle-label"><i class="fas fa-check-circle"></i> Settled (payouts / deductions)</div>
                <div class="settle-value">KES <?php echo number_format((float)$settlement['disbursed_amount'], 2); ?></div>
                <div class="settle-sub"><?php echo (int)$settlement['disbursed_count']; ?> payment(s) — settled through payouts or deductions</div>
            </div>
        </div>

        <!-- Auto-activation status for direct-to-ISP payments -->
        <?php if ($c2bStatus['mode'] === 'manual_paybill'): ?>
        <div class="autoact-banner off">
            <i class="fas fa-triangle-exclamation"></i>
            <div style="flex:1;min-width:220px;">
                <strong>Payments to your paybill are not being captured</strong>
                <div style="font-size:12px;opacity:.85;margin-top:3px;line-height:1.5;">
                    <?php echo htmlspecialchars($c2bStatus['reason']); ?>
                </div>
            </div>
            <button class="filter-btn" onclick="openImportModal('payments')">
                <i class="fas fa-file-import"></i> Import statement
            </button>
        </div>
        <?php endif; ?>

        <?php if ($c2bStatus['mode'] === 'direct'): ?>
        <div class="autoact-banner <?php echo $c2bStatus['active'] ? 'on' : 'off'; ?>">
            <i class="fas fa-<?php echo $c2bStatus['active'] ? 'bolt' : 'triangle-exclamation'; ?>"></i>
            <div style="flex:1;min-width:220px;">
                <strong><?php echo $c2bStatus['active'] ? 'Auto-activation is ON' : 'Auto-activation is OFF'; ?></strong>
                <div style="font-size:12px;opacity:.85;margin-top:3px;line-height:1.5;">
                    <?php echo htmlspecialchars($c2bStatus['reason']); ?>
                    <?php if ($c2bStatus['active'] && $c2bStatus['registered_at']): ?>
                        <br>Registered <?php echo date('d M Y H:i', strtotime($c2bStatus['registered_at'])); ?>.
                    <?php endif; ?>
                    <?php if ($c2bStatus['environment'] !== 'production' && $c2bStatus['environment'] !== 'live'): ?>
                        <br><strong>Sandbox credentials</strong> — real customer payments will not reach this.
                    <?php endif; ?>
                </div>
            </div>
            <?php if (!$c2bStatus['active']): ?>
            <button class="filter-btn primary" onclick="turnOnAutoActivation(<?php echo (int)$c2bStatus['gateway_id']; ?>, this)">
                <i class="fas fa-bolt"></i> Turn on
            </button>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if ($unmatchedCount > 0): ?>
        <div class="autoact-banner off">
            <i class="fas fa-question-circle"></i>
            <div style="flex:1;min-width:220px;">
                <strong><?php echo $unmatchedCount; ?> payment(s) arrived but matched no customer</strong>
                <div style="font-size:12px;opacity:.85;margin-top:3px;line-height:1.5;">
                    The money was received and recorded, but the account reference did not identify anyone,
                    so nobody was reconnected. Assign each one to a customer to credit and provision it.
                </div>
            </div>
            <button class="filter-btn primary" onclick="openUnmatchedModal()">
                <i class="fas fa-list-check"></i> Review
            </button>
        </div>
        <?php endif; ?>

        <!-- Recent Transactions -->
        <div class="transactions-section">
            <div class="transactions-header" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                <h3 class="transactions-title" style="margin:0;">Recent Transactions</h3>
                <div class="transactions-actions" style="display:flex; gap:10px; flex-wrap:wrap;">
                    <button class="filter-btn" onclick="exportPaymentsCSV()" style="display:flex;align-items:center;gap:6px;">
                        <i class="fas fa-download"></i> Export CSV
                    </button>
                    <button class="filter-btn" onclick="openImportModal('payments')" style="display:flex;align-items:center;gap:6px;">
                        <i class="fas fa-upload"></i> Import CSV
                    </button>
                    <button class="action-link manual filter-btn primary" onclick="openPaymentModal()">
                        <i class="fas fa-plus"></i> New Payment
                    </button>
                </div>
            </div>

            <!-- Status filter tabs -->
            <div class="tx-tabs">
                <button class="tx-tab active" onclick="filterTxRows('all',this)">All <span class="tc" id="tcAll"><?php echo count($transactions); ?></span></button>
                <button class="tx-tab" onclick="filterTxRows('completed',this)"><span style="color:#6ee7b7;font-size:8px;">●</span> Reconciled <span class="tc" id="tcCompleted">0</span></button>
                <button class="tx-tab" onclick="filterTxRows('pending',this)"><span style="color:#fcd34d;font-size:8px;">●</span> Pending <span class="tc" id="tcPending">0</span></button>
                <button class="tx-tab" onclick="filterTxRows('failed',this)"><span style="color:#fca5a5;font-size:8px;">●</span> Failed <span class="tc" id="tcFailed">0</span></button>
                <span class="tx-tab-sep"></span>
                <button class="tx-tab" onclick="filterTxRoute('direct',this)"><span style="color:#6ee7b7;font-size:8px;">●</span> Paid to you <span class="tc" id="tcDirect">0</span></button>
                <button class="tx-tab" onclick="filterTxRoute('awaiting',this)"><span style="color:#fcd34d;font-size:8px;">●</span> Awaiting disbursement <span class="tc" id="tcAwaiting">0</span></button>
                <button class="tx-tab" onclick="filterTxRoute('disbursed',this)"><span style="color:#93c5fd;font-size:8px;">●</span> Settled <span class="tc" id="tcDisbursed">0</span></button>
            </div>

          <div class="table-scroll" style="margin-top:14px;">
            <table class="transactions-table">
                <thead>
                    <tr>
                        <th>CUSTOMER / PHONE</th>
                        <th>AMOUNT</th>
                        <th>METHOD</th>
                        <th>TRANSACTION ID</th>
                        <th>STATUS</th>
                        <th>SETTLEMENT</th>
                        <th>DATE</th>
                        <th style="text-align:center;">ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($transactions)): ?>
                        <tr><td colspan="8" style="text-align:center;padding:20px;">No transactions found.</td></tr>
                    <?php else: ?>
                    <?php foreach ($transactions as $tx):
                        $status = $tx['status'] ?? 'pending';
                        $method = strtolower($tx['payment_method'] ?? 'cash');
                        // Use the same completed ledger state as dashboard totals.
                        $mpesaCode = (string)($tx['mpesa_result_code'] ?? '');
                        if ($status === 'completed') {
                            $badgeClass = 'completed'; $badgeLabel = 'Confirmed';
                        } elseif ($mpesaCode === '1032') {
                            $badgeClass = 'failed'; $badgeLabel = 'Cancelled';
                        } elseif ($mpesaCode === '1037') {
                            $badgeClass = 'failed'; $badgeLabel = 'Timed Out';
                        } elseif ($mpesaCode === '1' || $mpesaCode === '17') {
                            $badgeClass = 'failed'; $badgeLabel = 'Insufficient Funds';
                        } elseif ($status === 'failed' || ($mpesaCode !== '' && $mpesaCode !== '0')) {
                            $badgeClass = 'failed'; $badgeLabel = 'Failed';
                        } else {
                            $badgeClass = 'pending'; $badgeLabel = 'Pending';
                        }

                        // Settlement routing — whose account this money is in.
                        // 'platform' is FortuNett's till holding money owed to
                        // this ISP; released_at is the moment it was sent on.
                        // A failed/cancelled payment never moved money, so it
                        // gets no routing chip at all rather than a misleading one.
                        $collType = $tx['collection_type'] ?? 'direct';
                        $released = !empty($tx['released_at']);
                        if ($badgeClass === 'failed') {
                            $routeKey = 'none'; $routeLabel = 'No funds moved'; $routeSub = '';
                        } elseif ($badgeClass === 'pending') {
                            // Nothing has landed anywhere yet — claiming it is
                            // already in the ISP's account is how a failed STK
                            // gets counted as revenue.
                            $routeKey = 'none'; $routeLabel = 'Not yet received';
                            $routeSub = $collType === 'platform' ? 'Will settle via FortuNett till' : 'Will settle to you directly';
                        } elseif ($collType === 'platform') {
                            $routeKey   = $released ? 'disbursed' : 'awaiting';
                            $routeLabel = $released ? 'Settled' : 'Awaiting disbursement';
                            $routeSub   = $released
                                ? 'Settled ' . date('d M Y', strtotime($tx['released_at']))
                                : 'Held by FortuNett till';
                        } else {
                            $routeKey = 'direct'; $routeLabel = 'Paid to you directly';
                            $routeSub = strtolower($tx['payment_method'] ?? '') === 'cash'
                                ? 'Cash / manual entry' : 'Your own M-Pesa account';
                        }
                    ?>
                    <?php $txJson = htmlspecialchars(json_encode($tx), ENT_QUOTES, 'UTF-8'); ?>
                    <tr data-status="<?php echo $badgeClass; ?>" data-routing="<?php echo $routeKey; ?>">
                        <td>
                            <div class="customer-name"><?php echo htmlspecialchars($tx['full_name'] ?? 'Unknown'); ?></div>
                            <div class="customer-id"><?php echo htmlspecialchars($tx['phone'] ?? 'N/A'); ?></div>
                        </td>
                        <td>
                            <strong>KES <?php echo number_format($tx['amount'] ?? 0, 2); ?></strong>
                        </td>
                        <td>
                            <span class="payment-method <?php echo str_starts_with($method, 'mpesa') ? 'mpesa' : 'cash'; ?>">
                                <i class="fas fa-<?php echo str_starts_with($method, 'mpesa') ? 'mobile-alt' : 'money-bill'; ?>"></i>
                                <?php echo (!empty($tx['is_manual']) ? 'Manual entry / ' : '') . ($method === 'mpesa_stk' && empty($tx['is_manual']) ? 'M-Pesa (phone prompt)' : (str_starts_with($method, 'mpesa') ? 'M-Pesa' : htmlspecialchars(ucfirst(str_replace('_', ' ', $method))))); ?>
                            </span>
                        </td>
                        <td>
                            <?php
                                $displayId = $tx['transaction_id'] ?? 'N/A';
                                if ($mpesaCode === '1032') {
                                    echo '<span style="font-style:italic;color:#fca5a5;">Cancelled by customer</span>';
                                } elseif ($mpesaCode === '1037') {
                                    echo '<span style="font-style:italic;color:#fca5a5;">Timed out</span>';
                                } elseif ($status === 'pending' && strpos($displayId, 'ws_') === 0) {
                                    echo '<span style="font-style:italic;color:#9CA3AF;">Awaiting M-Pesa...</span>';
                                } elseif ($status === 'failed' && strpos($displayId, 'ws_') === 0) {
                                    $reason = $tx['mpesa_result_desc'] ?? '';
                                    echo '<span style="font-style:italic;color:#fca5a5;">' . htmlspecialchars($reason ?: 'Failed') . '</span>';
                                } else {
                                    echo '<span class="transaction-id" title="' . htmlspecialchars($tx['checkout_request_id'] ?? '') . '">' . htmlspecialchars($displayId) . '</span>';
                                }
                            ?>
                        </td>
                        <td>
                            <span class="status-badge <?php echo $badgeClass; ?>">
                                <?php echo $badgeLabel; ?>
                            </span>
                        </td>
                        <td>
                            <span class="route-chip <?php echo $routeKey; ?>">
                                <span class="dot"></span><?php echo $routeLabel; ?>
                            </span>
                            <?php if ($routeSub): ?><div class="route-sub"><?php echo htmlspecialchars($routeSub); ?></div><?php endif; ?>
                        </td>
                        <td><?php echo date('d/m/Y H:i', strtotime($tx['payment_date'] ?? $tx['created_at'])); ?></td>
                        <td style="text-align:center;">
                            <div class="dot-menu-wrap">
                                <button class="dot-menu-btn" onclick="toggleDotMenu(this)" title="Actions">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <div class="dot-menu-dropdown">
                                    <button class="dot-menu-item" onclick="openViewModal(<?php echo $txJson; ?>);closeDotMenus()">
                                        <i class="fas fa-eye"></i> View Details
                                    </button>
                                    <button class="dot-menu-item" onclick="printReceipt(<?php echo $txJson; ?>);closeDotMenus()">
                                        <i class="fas fa-print"></i> Print Receipt
                                    </button>
                                    <button class="dot-menu-item sep" onclick="openPaymentStatus(<?php echo $txJson; ?>);closeDotMenus()">
                                        <i class="fas fa-satellite-dish"></i> Payment Status
                                    </button>
                                    <?php if (!empty($tx['is_manual'])): ?>
                                    <button class="dot-menu-item sep" onclick="openEditPayment(<?php echo $txJson; ?>);closeDotMenus()">
                                        <i class="fas fa-pen"></i> Edit Entry
                                    </button>
                                    <button class="dot-menu-item danger" onclick="confirmDeletePayment(<?php echo $txJson; ?>);closeDotMenus()">
                                        <i class="fas fa-trash"></i> Delete Entry
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
          </div><!-- end table-scroll -->
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div id="paymentModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);z-index:1050;overflow-y:auto;-webkit-overflow-scrolling:touch;align-items:flex-start;justify-content:center;padding:40px 16px 24px;box-sizing:border-box;">
    <div style="background:#1e1e1d;border:1px solid rgba(255,255,255,.08);width:100%;max-width:620px;max-height:calc(100vh - 80px);border-radius:16px;box-shadow:0 32px 80px rgba(0,0,0,.8);display:flex;flex-direction:column;overflow:hidden;margin:auto 0;">

        <!-- Modal Header -->
        <div style="padding:20px 24px;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;justify-content:space-between;flex-shrink:0;">
            <div>
                <h2 style="font-size:18px;font-weight:700;color:#e2e2e0;margin:0 0 2px 0;">Payment Entry</h2>
                <p style="font-size:13px;color:rgba(255,255,255,.4);margin:0;">Initiate or record a customer payment</p>
            </div>
            <button onclick="closePaymentModal()" style="width:32px;height:32px;border-radius:50%;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.06);color:rgba(255,255,255,.6);cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">&times;</button>
        </div>

        <!-- Tab Navigation -->
        <div style="display:flex;border-bottom:1px solid rgba(255,255,255,.07);flex-shrink:0;background:rgba(255,255,255,.02);">
            <button id="tabBtnNew" class="tab-button active" onclick="showPaymentTab('newPaymentTab')"
                style="flex:1;padding:12px;border:none;background:none;cursor:pointer;font-size:14px;font-weight:600;color:var(--primary-light,#93c5fd);border-bottom:2px solid var(--primary-light,#93c5fd);transition:all .2s;">
                <i class="fas fa-bolt" style="margin-right:6px;"></i>New Payment
            </button>
            <button id="tabBtnPast" class="tab-button" onclick="showPaymentTab('recordPastTab')"
                style="flex:1;padding:12px;border:none;background:none;cursor:pointer;font-size:14px;font-weight:500;color:rgba(255,255,255,.4);border-bottom:2px solid transparent;transition:all .2s;">
                <i class="fas fa-history" style="margin-right:6px;"></i>Record Past Transaction
            </button>
        </div>

        <!-- Scrollable Body -->
        <div style="overflow-y:auto;flex:1;padding:24px;">

            <!-- Tab 1: New Payment (STK Push / Manual Cash) -->
            <div id="newPaymentTab" class="tab-content">
                <div id="sandboxBanner"><i class="fas fa-flask" style="margin-right:7px;"></i><strong>Sandbox Mode Active</strong> — STK pushes are accepted by Safaricom but no real prompt appears on any phone. Go to <strong>Settings → Payments</strong> and set your M-Pesa gateway to <strong>Production</strong>.</div>
                <form id="newPaymentForm" onsubmit="handlePaymentSubmit(event)">
                    <!-- Section: Customer -->
                    <div style="margin-bottom:18px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.06);">
                        <p style="font-size:11px;font-weight:700;color:rgba(255,255,255,.35);text-transform:uppercase;letter-spacing:.06em;margin:0 0 12px 0;">Customer</p>
                        <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Select Customer</label>
                        <select name="client_id" id="payClient" required class="pay-input"
                            onchange="updatePhone(this)">
                            <option value="">Select a customer...</option>
                            <?php foreach ($clients as $c): ?>
                            <option value="<?php echo $c['id']; ?>" data-phone="<?php echo htmlspecialchars($c['phone']); ?>">
                                <?php echo htmlspecialchars($c['full_name']); ?> — <?php echo htmlspecialchars($c['phone']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <!-- Section: Payment Details -->
                    <div style="margin-bottom:18px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.06);">
                        <p style="font-size:11px;font-weight:700;color:rgba(255,255,255,.35);text-transform:uppercase;letter-spacing:.06em;margin:0 0 12px 0;">Payment Details</p>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">
                            <div>
                                <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Phone (M-Pesa)</label>
                                <input type="text" name="phone" id="payPhone" required placeholder="2547XXXXXXXX" class="pay-input">
                            </div>
                            <div>
                                <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Amount (KES)</label>
                                <input type="number" name="amount" id="payAmount" required placeholder="0.00" min="1" step="0.01" class="pay-input">
                            </div>
                        </div>
                        <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:8px;">Payment Method</label>
                        <div style="display:flex;gap:10px;">
                            <label id="radioMpesa" class="pay-method-label pay-method-active">
                                <input type="radio" name="method" value="mpesa" checked onchange="highlightMethodRadio()"> <i class="fas fa-mobile-alt"></i> M-Pesa STK
                            </label>
                            <label id="radioCash" class="pay-method-label">
                                <input type="radio" name="method" value="cash" onchange="highlightMethodRadio()"> <i class="fas fa-money-bill"></i> Manual Cash
                            </label>
                        </div>
                    </div>
                    <button type="submit" id="newPayBtn" class="pay-submit-btn">
                        <i class="fas fa-paper-plane" style="margin-right:8px;"></i>Process Payment
                    </button>
                </form>
            </div>

            <!-- Tab 2: Record Past Transaction -->
            <div id="recordPastTab" class="tab-content" style="display:none;">
                <form id="recordPastForm" onsubmit="handleRecordPastSubmit(event)">

                    <!-- Section: Transaction Details -->
                    <div style="margin-bottom:18px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.06);">
                        <p style="font-size:11px;font-weight:700;color:rgba(255,255,255,.35);text-transform:uppercase;letter-spacing:.06em;margin:0 0 12px 0;">Transaction Details</p>

                        <div style="margin-bottom:14px;">
                            <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Customer <span style="color:#f87171;">*</span></label>
                            <select name="client_id" id="recordClient" required class="pay-input">
                                <option value="">Select a customer...</option>
                                <?php foreach ($clients as $c): ?>
                                <option value="<?php echo $c['id']; ?>">
                                    <?php echo htmlspecialchars($c['full_name']); ?> — <?php echo htmlspecialchars($c['phone']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">
                            <div>
                                <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Amount (KES) <span style="color:#f87171;">*</span></label>
                                <input type="number" name="amount" required placeholder="0.00" min="1" step="0.01" class="pay-input">
                            </div>
                            <div>
                                <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Payment Method <span style="color:#f87171;">*</span></label>
                                <select name="method" required class="pay-input">
                                    <option value="">Select...</option>
                                    <option value="M-Pesa">M-Pesa</option>
                                    <option value="Cash">Cash</option>
                                    <option value="Bank Transfer">Bank Transfer</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Reference / Confirmation Code <span style="color:#f87171;">*</span></label>
                            <input type="text" name="reference_code" id="recordRef" required
                                placeholder="e.g. QJK3X7A1P2 — M-Pesa code, bank ref, receipt #"
                                class="pay-input" style="font-family:monospace;letter-spacing:.04em;"
                                oninput="this.value=this.value.toUpperCase();queueRefCheck(this,'recordRefHint',null)">
                            <div class="ref-hint" id="recordRefHint"></div>
                        </div>
                    </div>

                    <!-- Section: Date & Verification -->
                    <div style="margin-bottom:18px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.06);">
                        <p style="font-size:11px;font-weight:700;color:rgba(255,255,255,.35);text-transform:uppercase;letter-spacing:.06em;margin:0 0 12px 0;">Date &amp; Verification</p>

                        <div style="margin-bottom:14px;">
                            <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Date &amp; Time of Payment <span style="color:#f87171;">*</span></label>
                            <input type="datetime-local" name="transaction_date" required value="<?php echo date('Y-m-d\TH:i'); ?>" class="pay-input">
                        </div>

                        <div style="margin-bottom:14px;">
                            <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Notes (optional)</label>
                            <input type="text" name="notes" placeholder="e.g. Customer called to confirm payment" class="pay-input">
                        </div>

                        <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;padding:14px 16px;background:rgba(52,211,153,.06);border:1px solid rgba(52,211,153,.2);border-radius:8px;">
                            <input type="checkbox" name="is_verified" value="1" checked
                                style="width:16px;height:16px;accent-color:#34d399;flex-shrink:0;margin-top:1px;">
                            <div>
                                <div style="font-size:13px;font-weight:600;color:#6ee7b7;">Mark as Verified / Confirmed</div>
                                <div style="font-size:12px;color:rgba(255,255,255,.4);margin-top:2px;">Records as "Confirmed" — use only when you have verified the payment reference is genuine.</div>
                            </div>
                        </label>
                    </div>

                    <button type="submit" id="recordPastBtn" class="pay-submit-btn">
                        <i class="fas fa-save" style="margin-right:8px;"></i>Record Transaction
                    </button>
                </form>
            </div>

        </div><!-- end scrollable body -->
    </div>
</div>

<!-- Edit Entry Modal — hand-entered payments only -->
<div id="editPaymentModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);z-index:1000;align-items:center;justify-content:center;padding:16px;box-sizing:border-box;">
    <div style="background:#1e1e1d;border:1px solid rgba(255,255,255,.08);width:100%;max-width:520px;border-radius:16px;box-shadow:0 32px 80px rgba(0,0,0,.8);display:flex;flex-direction:column;max-height:92vh;">
        <div style="padding:20px 24px;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;justify-content:space-between;flex-shrink:0;">
            <div>
                <h2 style="font-size:18px;font-weight:700;color:#e2e2e0;margin:0 0 2px 0;">Edit Recorded Entry</h2>
                <p style="font-size:13px;color:rgba(255,255,255,.4);margin:0;" id="editPayWho">&nbsp;</p>
            </div>
            <button onclick="closeEditPayment()" style="width:32px;height:32px;border-radius:50%;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.06);color:rgba(255,255,255,.6);cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">&times;</button>
        </div>

        <form id="editPaymentForm" onsubmit="submitEditPayment(event)" style="overflow-y:auto;padding:24px;">
            <input type="hidden" name="payment_id" id="editPayId">

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">
                <div>
                    <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Amount (KES)</label>
                    <input type="number" name="amount" id="editPayAmount" required min="1" step="0.01" class="pay-input">
                </div>
                <div>
                    <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Method</label>
                    <select name="method" id="editPayMethod" class="pay-input">
                        <option value="mpesa">M-Pesa</option>
                        <option value="cash">Cash</option>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="card">Card</option>
                    </select>
                </div>
            </div>

            <div style="margin-bottom:14px;">
                <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Reference / Confirmation Code</label>
                <input type="text" name="reference" id="editPayRef" required class="pay-input"
                       style="font-family:monospace;letter-spacing:.04em;"
                       oninput="this.value=this.value.toUpperCase();queueRefCheck(this,'editPayRefHint',document.getElementById('editPayId').value)">
                <div class="ref-hint" id="editPayRefHint"></div>
                <div style="font-size:12px;color:rgba(255,255,255,.35);margin-top:6px;line-height:1.45;">
                    Changing this renames the invoice, the ledger entries and any queued settlement so they keep pointing at this payment.
                </div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">
                <div>
                    <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Date &amp; Time</label>
                    <input type="datetime-local" name="payment_date" id="editPayDate" class="pay-input">
                </div>
                <div>
                    <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Status</label>
                    <select name="status" id="editPayStatus" class="pay-input">
                        <option value="completed">Confirmed</option>
                        <option value="pending">Unverified</option>
                    </select>
                </div>
            </div>

            <div style="margin-bottom:18px;">
                <label style="display:block;font-size:13px;font-weight:500;color:rgba(255,255,255,.6);margin-bottom:6px;">Notes</label>
                <input type="text" name="notes" id="editPayNotes" class="pay-input" placeholder="Optional">
            </div>

            <div id="editPayConfirmNote" style="display:none;font-size:12.5px;color:#fcd34d;background:rgba(217,119,6,.1);border:1px solid rgba(217,119,6,.28);border-radius:8px;padding:12px 14px;margin-bottom:16px;line-height:1.5;">
                Moving this to <strong>Confirmed</strong> also reconnects the customer, extends their expiry and texts them their login — the same thing recording a verified payment does.
            </div>

            <button type="submit" id="editPayBtn" class="pay-submit-btn">
                <i class="fas fa-save" style="margin-right:8px;"></i>Save Changes
            </button>
        </form>
    </div>
</div>

<!-- Delete Entry Modal -->
<div id="deletePaymentModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);z-index:1001;align-items:center;justify-content:center;padding:16px;box-sizing:border-box;">
    <div style="background:#1e1e1d;border:1px solid rgba(239,68,68,.25);width:100%;max-width:480px;border-radius:16px;box-shadow:0 32px 80px rgba(0,0,0,.8);padding:26px;">
        <h2 style="font-size:17px;font-weight:700;color:#fca5a5;margin:0 0 6px 0;display:flex;align-items:center;gap:10px;">
            <i class="fas fa-triangle-exclamation"></i> Delete this entry?
        </h2>
        <p style="font-size:13px;color:rgba(255,255,255,.45);margin:0 0 18px 0;line-height:1.5;">
            This removes the payment and everything it produced — the invoice, the ledger entries, any commission and any queued settlement. It cannot be undone.
        </p>

        <div id="deletePaySummary" style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:14px 16px;font-size:13px;color:#d4d4d2;line-height:1.7;margin-bottom:16px;"></div>

        <label id="deletePayRevokeWrap" style="display:none;align-items:flex-start;gap:10px;cursor:pointer;padding:13px 15px;background:rgba(217,119,6,.08);border:1px solid rgba(217,119,6,.25);border-radius:8px;margin-bottom:18px;">
            <input type="checkbox" id="deletePayRevoke" style="width:16px;height:16px;accent-color:#fbbf24;flex-shrink:0;margin-top:1px;">
            <div>
                <div style="font-size:13px;font-weight:600;color:#fcd34d;">Also take back the access it granted</div>
                <div style="font-size:12px;color:rgba(255,255,255,.4);margin-top:2px;" id="deletePayRevokeNote"></div>
            </div>
        </label>

        <div id="deletePayRevokeBlocked" style="display:none;font-size:12.5px;color:rgba(255,255,255,.45);background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:8px;padding:12px 14px;margin-bottom:18px;line-height:1.5;"></div>

        <div style="display:flex;gap:10px;justify-content:flex-end;">
            <button type="button" onclick="closeDeletePayment()" class="filter-btn">Cancel</button>
            <button type="button" id="deletePayBtn" onclick="doDeletePayment()"
                style="padding:10px 20px;background:linear-gradient(135deg,#b91c1c,#ef4444);color:#fff;border:none;border-radius:8px;cursor:pointer;font-weight:600;font-size:13px;">
                <i class="fas fa-trash" style="margin-right:7px;"></i>Delete permanently
            </button>
        </div>
    </div>
</div>

<!-- View Modal -->
<div id="viewModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);z-index:1000;align-items:center;justify-content:center;padding:16px;box-sizing:border-box;">
    <div style="background:#1e1e1d;border:1px solid rgba(255,255,255,.08);width:100%;max-width:500px;border-radius:16px;padding:32px;position:relative;box-shadow:0 32px 80px rgba(0,0,0,.8);">
        <button onclick="closeViewModal()" style="position:absolute;top:20px;right:20px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:50%;width:32px;height:32px;font-size:18px;cursor:pointer;color:rgba(255,255,255,.6);display:flex;align-items:center;justify-content:center;">&times;</button>
        <h2 style="font-size:20px;font-weight:600;color:#e2e2e0;margin:0 0 24px 0;">Transaction Details</h2>
        <div id="viewModalContent"></div>
        <div style="margin-top:24px;text-align:right;">
            <button onclick="printCurrentReceipt()" style="padding:10px 20px;background:linear-gradient(135deg,var(--primary-dark,#2C5282),var(--primary-color,#3B6EA5));color:white;border:none;border-radius:8px;cursor:pointer;font-weight:600;">Print Receipt</button>
        </div>
    </div>
</div>

<script>
function openPaymentModal() {
    document.getElementById('paymentModal').style.display = 'flex';
    showPaymentTab('newPaymentTab'); // Default to 'New Payment' tab
}

function closePaymentModal() {
    document.getElementById('paymentModal').style.display = 'none';
    document.getElementById('newPaymentForm').reset(); // Reset new payment form
    document.getElementById('recordPastForm').reset(); // Reset record past form
}

function showPaymentTab(tabId) {
    document.querySelectorAll('#paymentModal .tab-content').forEach(t => t.style.display = 'none');
    document.getElementById(tabId).style.display = 'block';

    const primary = getComputedStyle(document.documentElement).getPropertyValue('--primary-light').trim() || '#93c5fd';
    ['tabBtnNew','tabBtnPast'].forEach(id => {
        const btn = document.getElementById(id);
        if (!btn) return;
        btn.style.color = 'rgba(255,255,255,.4)';
        btn.style.borderBottom = '2px solid transparent';
        btn.style.fontWeight = '500';
    });
    const activeId = tabId === 'newPaymentTab' ? 'tabBtnNew' : 'tabBtnPast';
    const active = document.getElementById(activeId);
    if (active) {
        active.style.color = primary;
        active.style.borderBottom = '2px solid ' + primary;
        active.style.fontWeight = '600';
    }
}

function highlightMethodRadio() {
    const mpesa = document.querySelector('input[name="method"][value="mpesa"]');
    const lMpesa = document.getElementById('radioMpesa');
    const lCash  = document.getElementById('radioCash');
    if (!lMpesa || !lCash) return;
    if (mpesa && mpesa.checked) {
        lMpesa.classList.add('pay-method-active');
        lCash.classList.remove('pay-method-active');
    } else {
        lCash.classList.add('pay-method-active');
        lMpesa.classList.remove('pay-method-active');
    }
}

function updatePhone(select) {
    const option = select.options[select.selectedIndex];
    if (option.dataset.phone) {
        document.getElementById('payPhone').value = option.dataset.phone;
    }
}

function handlePaymentSubmit(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    const method = formData.get('method');
    
    // Determine URL based on method
    let url = 'api/payment/stk_push.php';
    if (method === 'cash') {
        url = 'api/payments/record_cash.php';
    }
    
    const btn = document.getElementById('newPayBtn') || form.querySelector('button[type="submit"]');
    const originalHTML = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin" style="margin-right:8px;"></i>Processing...';
    btn.disabled = true;
    
    fetch(url, {
        method: 'POST',
        body: formData
    })
    .then(r => {
        if (!r.ok) throw new Error('Server returned ' + r.status);
        return r.json();
    })
    .then(data => {
        if (data.success) {
            if (method === 'cash') {
                showFnToast('Cash payment recorded successfully', 'success');
                closePaymentModal();
                setTimeout(() => location.reload(), 1800);
            } else if (data.sandbox) {
                // Sandbox — show inline warning, don't close modal
                const banner = document.getElementById('sandboxBanner');
                if (banner) banner.style.display = 'block';
                showFnToast('⚠️ SANDBOX: No phone prompt sent. Switch to Production in Settings → Payments.', 'warning');
                btn.innerHTML = originalHTML;
                btn.disabled = false;
            } else {
                const baseMsg = data.using_platform
                    ? 'STK request accepted via FortuNett paybill. If no phone prompt appears within 30s, the shortcode may not be enrolled for LNM Online — contact your admin.'
                    : (data.CustomerMessage || 'STK Push sent — check your phone.');
                showFnToast(baseMsg, 'success');
                closePaymentModal();
                setTimeout(() => location.reload(), 1800);
            }
        } else {
            const errMsg = data.message || data.errorMessage || 'Unknown error';
            showFnToast(errMsg, 'error');
            btn.innerHTML = originalHTML;
            btn.disabled = false;
        }
    })
    .catch(err => {
        console.error(err);
        showFnToast('Connection error. Check your network.', 'error');
        btn.innerHTML = originalHTML;
        btn.disabled = false;
    });
}

function handleRecordPastSubmit(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    
    const btn = document.getElementById('recordPastBtn') || form.querySelector('button[type="submit"]');
    const originalHTML = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin" style="margin-right:8px;"></i>Saving...';
    btn.disabled = true;

    fetch('api/payments/record_manual.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showFnToast('✅ Transaction recorded: ' + data.transaction_id, 'success');
            closePaymentModal();
            setTimeout(() => location.reload(), 1500);
        } else {
            showFnToast('Error: ' + (data.message || 'Unknown error'), 'error');
        }
    })
    .catch(() => showFnToast('Connection error. Please try again.', 'error'))
    .finally(() => { btn.innerHTML = originalHTML; btn.disabled = false; });
}

function showFnToast(message, type) {
    const existing = document.getElementById('fnToast');
    if (existing) existing.remove();
    const bg = type === 'success' ? 'rgba(16,185,129,.9)' : type === 'warning' ? 'rgba(217,119,6,.9)' : 'rgba(239,68,68,.9)';
    const icon = type === 'success' ? 'fa-check-circle' : type === 'warning' ? 'fa-exclamation-triangle' : 'fa-exclamation-circle';
    const toast = document.createElement('div');
    toast.id = 'fnToast';
    toast.style.cssText = `position:fixed;top:20px;right:20px;z-index:9999;background:${bg};backdrop-filter:blur(8px);color:white;padding:14px 20px;border-radius:10px;font-size:13px;font-weight:600;display:flex;align-items:flex-start;gap:10px;box-shadow:0 8px 32px rgba(0,0,0,.5);max-width:420px;line-height:1.4;`;
    toast.innerHTML = `<i class="fas ${icon}" style="flex-shrink:0;margin-top:1px;"></i><span>${message}</span>`;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), type === 'warning' ? 8000 : 4000);
}

/* ─────────────────────────────────────────────────────────────────────────────
   Editing and deleting a HAND-ENTERED payment.

   Both menu items are rendered only for rows the server flagged is_manual, and
   both endpoints re-check that themselves -- the UI decides what to offer, it
   never decides what is allowed.
   ───────────────────────────────────────────────────────────────────────────── */

/* Live duplicate check. Debounced because it fires on every keystroke, and
   deliberately advisory: record_manual.php and update_manual.php enforce the
   rule whatever this says, so a slow or failed lookup can never let a duplicate
   through -- it just stops warning. */
let _refCheckTimer = null;

function queueRefCheck(input, hintId, excludePaymentId) {
  const hint = document.getElementById(hintId);
  const ref  = (input.value || '').trim();

  clearTimeout(_refCheckTimer);
  input.classList.remove('ref-bad');

  if (ref.length < 3) {
    hint.className = 'ref-hint';
    hint.textContent = '';
    return;
  }

  hint.className = 'ref-hint show checking';
  hint.textContent = 'Checking this code…';

  _refCheckTimer = setTimeout(() => {
    const qs = new URLSearchParams({ reference: ref });
    if (excludePaymentId) qs.set('payment_id', excludePaymentId);

    fetch('api/payments/check_reference.php?' + qs.toString())
      .then(r => r.json())
      .then(d => {
        if ((input.value || '').trim() !== ref) return;   /* they kept typing */
        if (!d.success) { hint.className = 'ref-hint'; return; }
        if (d.available) {
          hint.className = 'ref-hint show good';
          hint.textContent = 'This code is not yet used.';
        } else {
          hint.className = 'ref-hint show bad';
          hint.textContent = d.message;
          input.classList.add('ref-bad');
        }
      })
      .catch(() => { hint.className = 'ref-hint'; hint.textContent = ''; });
  }, 350);
}

/* ── Edit ─────────────────────────────────────────────────────────────────── */
function openEditPayment(tx) {
  document.getElementById('editPayId').value     = tx.id;
  document.getElementById('editPayAmount').value = parseFloat(tx.amount || 0).toFixed(2);
  document.getElementById('editPayRef').value    = tx.transaction_id || '';
  document.getElementById('editPayMethod').value = tx.payment_method || 'cash';
  document.getElementById('editPayStatus').value = (tx.status === 'completed') ? 'completed' : 'pending';
  document.getElementById('editPayNotes').value  = tx.notes || '';
  document.getElementById('editPayWho').textContent =
    (tx.full_name || 'Unknown customer') + ' · ' + (tx.phone || '');

  /* payment_date is 'YYYY-MM-DD HH:MM:SS'; datetime-local wants the T form and
     no seconds. A deployment that never ran the payment-date-to-DATETIME
     migration stores a bare 'YYYY-MM-DD', which is midnight -- fill that in
     rather than showing an empty field the operator has to retype. Anything
     else is left blank on purpose: posting an empty date leaves the stored one
     untouched, which is safer than guessing at it. */
  let d = String(tx.payment_date || '').replace(' ', 'T').slice(0, 16);
  if (/^\d{4}-\d{2}-\d{2}$/.test(d)) d += 'T00:00';
  document.getElementById('editPayDate').value = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(d) ? d : '';

  document.getElementById('editPayRefHint').className = 'ref-hint';
  document.getElementById('editPayRefHint').textContent = '';
  document.getElementById('editPayRef').classList.remove('ref-bad');

  /* Warn only when this edit is what confirms the payment. */
  const wasPending = tx.status !== 'completed';
  const note = document.getElementById('editPayConfirmNote');
  document.getElementById('editPayStatus').onchange = function () {
    note.style.display = (wasPending && this.value === 'completed') ? 'block' : 'none';
  };
  note.style.display = 'none';

  document.getElementById('editPaymentModal').style.display = 'flex';
}

function closeEditPayment() {
  document.getElementById('editPaymentModal').style.display = 'none';
}

function submitEditPayment(e) {
  e.preventDefault();
  const form = e.target;
  const btn  = document.getElementById('editPayBtn');
  const original = btn.innerHTML;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin" style="margin-right:8px;"></i>Saving…';
  btn.disabled = true;

  fetch('api/payments/update_manual.php', { method: 'POST', body: new FormData(form) })
    .then(r => r.json())
    .then(d => {
      if (d.success) {
        showFnToast('✅ ' + d.message, 'success');
        closeEditPayment();
        setTimeout(() => location.reload(), 1400);
      } else {
        showFnToast(d.message || 'Could not save the change.', 'error');
      }
    })
    .catch(() => showFnToast('Connection error. Please try again.', 'error'))
    .finally(() => { btn.innerHTML = original; btn.disabled = false; });
}

/* ── Delete ───────────────────────────────────────────────────────────────── */
let _deletePayId = null;

function confirmDeletePayment(tx) {
  _deletePayId = tx.id;

  const box = document.getElementById('deletePaySummary');
  box.innerHTML =
      '<div><span style="color:rgba(255,255,255,.4);">Customer</span> &nbsp;' + escapeHtmlPay(tx.full_name || '—') + '</div>'
    + '<div><span style="color:rgba(255,255,255,.4);">Amount</span> &nbsp;<strong>KES '
    + Number(tx.amount || 0).toLocaleString(undefined, {minimumFractionDigits: 2}) + '</strong></div>'
    + '<div><span style="color:rgba(255,255,255,.4);">Reference</span> &nbsp;<span style="font-family:monospace;">'
    + escapeHtmlPay(tx.transaction_id || '—') + '</span></div>';

  /* Ask the server what it would do before offering the choice: whether the
     expiry can be rolled back exactly is a question about this customer's later
     payments, which the browser cannot answer. */
  const wrap    = document.getElementById('deletePayRevokeWrap');
  const blocked = document.getElementById('deletePayRevokeBlocked');
  wrap.style.display = 'none';
  blocked.style.display = 'none';
  document.getElementById('deletePayRevoke').checked = false;

  const fd = new FormData();
  fd.append('payment_id', tx.id);
  fd.append('preview', '1');

  fetch('api/payments/delete_manual.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(d => {
      if (!d.success) {
        closeDeletePayment();
        showFnToast(d.message || 'This entry cannot be deleted.', 'error');
        return;
      }
      const rev = d.revocation || {};
      if (rev.applied) {
        document.getElementById('deletePayRevokeNote').textContent =
          'Rolls the expiry back by ' + rev.period + ' (the ' + rev.package + ' period this entry paid for), to '
          + new Date(rev.new_expiry.replace(' ', 'T')).toLocaleString() + '.';
        wrap.style.display = 'flex';
      } else if (rev.reason && rev.reason !== 'not requested') {
        blocked.textContent = 'The customer\u2019s expiry will be left as it is — ' + rev.reason;
        blocked.style.display = 'block';
      }
    })
    .catch(() => { /* the delete itself still guards; just offer no rollback */ });

  document.getElementById('deletePaymentModal').style.display = 'flex';
}

function closeDeletePayment() {
  document.getElementById('deletePaymentModal').style.display = 'none';
  _deletePayId = null;
}

function doDeletePayment() {
  if (!_deletePayId) return;
  const btn = document.getElementById('deletePayBtn');
  const original = btn.innerHTML;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin" style="margin-right:7px;"></i>Deleting…';
  btn.disabled = true;

  const fd = new FormData();
  fd.append('payment_id', _deletePayId);
  if (document.getElementById('deletePayRevoke').checked) fd.append('revoke_access', '1');

  fetch('api/payments/delete_manual.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(d => {
      if (d.success) {
        showFnToast('🗑 ' + d.message, 'success');
        closeDeletePayment();
        setTimeout(() => location.reload(), 1600);
      } else {
        showFnToast(d.message || 'Could not delete the entry.', 'error');
      }
    })
    .catch(() => showFnToast('Connection error. Please try again.', 'error'))
    .finally(() => { btn.innerHTML = original; btn.disabled = false; });
}

function escapeHtmlPay(v) {
  return String(v == null ? '' : v).replace(/[&<>"']/g, c => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

let currentViewTx = null;

function openViewModal(tx) {
    currentViewTx = tx;
    const content = document.getElementById('viewModalContent');
    const recordedMethod = String(tx.payment_method || tx.method || '').toLowerCase();
    const methodLabels = {mpesa_stk:'M-Pesa (phone prompt)', mpesa:'M-Pesa', mpesa_paybill:'M-Pesa Paybill', mpesa_c2b:'M-Pesa Paybill', cash:'Cash', bank_transfer:'Bank transfer', card:'Card'};
    const manualEntry = Number(tx.is_manual) === 1;
    const displayMethod = manualEntry && recordedMethod === 'mpesa_stk' ? 'mpesa' : recordedMethod;
    const method = (manualEntry ? 'Manual entry / ' : '') + (methodLabels[displayMethod] || (displayMethod ? escapeHtmlPay(displayMethod) : 'Not recorded'));

    // Match the payment ledger and dashboard; a prompt response is not payment.
    const status = tx.status || 'pending';

    const statusClass = status === 'completed' ? 'color: #059669; background: #D1FAE5;' : 
                        (status === 'failed' ? 'color: #DC2626; background: #FEE2E2;' : 'color: #D97706; background: #FEF3C7;');
    
    const statusCls = status === 'completed'
        ? 'background:rgba(16,185,129,.15);color:#6ee7b7;border:1px solid rgba(16,185,129,.25);'
        : status === 'failed'
        ? 'background:rgba(239,68,68,.15);color:#fca5a5;border:1px solid rgba(239,68,68,.25);'
        : 'background:rgba(245,158,11,.15);color:#fcd34d;border:1px solid rgba(245,158,11,.25);';
    content.innerHTML = `
        <div class="vm-grid">
            <div>
                <div class="vm-label">Customer</div>
                <div class="vm-value">${tx.full_name || 'Unknown'}</div>
                <div class="vm-sub">${tx.phone || 'N/A'}</div>
            </div>
            <div>
                <div class="vm-label">Amount</div>
                <div class="vm-value" style="font-size:22px;">KSh ${parseFloat(tx.amount).toLocaleString()}</div>
            </div>
        </div>
        <div class="vm-detail-box">
            <div class="vm-row"><span class="vm-row-label">Transaction ID</span><span class="vm-row-val">${tx.mpesa_receipt_number || tx.transaction_id || 'N/A'}</span></div>
            <div class="vm-row"><span class="vm-row-label">Date</span><span class="vm-row-val" style="font-family:inherit;">${new Date(tx.created_at || tx.payment_date).toLocaleString()}</span></div>
            <div class="vm-row"><span class="vm-row-label">Method</span><span class="vm-row-val" style="font-family:inherit;">${method}</span></div>
            <div class="vm-row"><span class="vm-row-label">Status</span><span style="padding:3px 10px;border-radius:12px;font-size:12px;font-weight:600;${statusCls}">${status.toUpperCase()}</span></div>
        </div>
    `;
    
    document.getElementById('viewModal').style.display = 'flex';
}

function closeViewModal() {
    document.getElementById('viewModal').style.display = 'none';
    currentViewTx = null;
}

// Backdrop click-to-close
document.getElementById('paymentModal').addEventListener('click', function(e) { if (e.target === this) closePaymentModal(); });
document.getElementById('viewModal').addEventListener('click', function(e) { if (e.target === this) closeViewModal(); });

// Auto-open payment modal when navigated from quick actions
if (new URLSearchParams(window.location.search).get('open_modal') === '1') {
    openPaymentModal();
}

function printCurrentReceipt() {
    if (currentViewTx) printReceipt(currentViewTx);
}

function printReceipt(tx) {
    const printWindow = window.open('', '_blank', 'width=400,height=600');
    if (!printWindow) { return alert('Please allow popups to print receipts.'); }
    
    const html = `
        <html>
        <head>
            <title>Receipt - ${tx.mpesa_receipt_number || tx.transaction_id || tx.id}</title>
            <style>
                body { font-family: 'Courier New', Courier, monospace; padding: 20px; text-align: center; }
                .header { margin-bottom: 20px; border-bottom: 1px dashed #000; padding-bottom: 10px; }
                .company { font-size: 18px; font-weight: bold; }
                .meta { font-size: 12px; color: #555; margin-bottom: 20px; }
                .details { text-align: left; margin-bottom: 20px; }
                .row { display: flex; justify-content: space-between; margin-bottom: 5px; }
                .total { border-top: 1px dashed #000; border-bottom: 1px dashed #000; padding: 10px 0; font-weight: bold; font-size: 16px; margin: 20px 0; }
                .footer { font-size: 10px; color: #777; margin-top: 30px; }
            </style>
        </head>
        <body>
            <div class="header">
                <div class="company">FORTUNNET TECHNOLOGIES</div>
                <div>Internet Service Provider</div>
                <div>Tel: 0700 000 000</div>
            </div>
            
            <div class="meta">
                Receipt #: ${tx.id}<br>
                Date: ${new Date(tx.created_at || tx.payment_date).toLocaleString()}
            </div>
            
            <div class="details">
                <div class="row">
                    <span>Customer:</span>
                    <span>${tx.full_name || 'Customer'}</span>
                </div>
                <!-- Remove Payment Method and Ref to execute user.receipt request cleanly -->
                <div class="row">
                    <span>Account:</span>
                    <span>${tx.phone}</span>
                </div>
                <div class="row">
                    <span>Ref:</span>
                    <span>${tx.mpesa_receipt_number || tx.transaction_id || '-'}</span>
                </div>
            </div>
            
            <div class="total">
                <div class="row">
                    <span>TOTAL PAID:</span>
                    <span>KES ${parseFloat(tx.amount).toLocaleString()}</span>
                </div>
            </div>
            
            <div class="footer">
                Thank you for your business!<br>
                This is a computer generated receipt.
            </div>
            <script>
                window.onload = function() { window.print(); window.close(); }
            <\/script>
        </body>
        </html>
    `;
    
    printWindow.document.write(html);
    printWindow.document.close();
}

function exportPaymentsCSV() {
    const params = new URLSearchParams(window.location.search);
    params.set('export', 'csv');
    window.location.href = 'payments.php?' + params.toString();
}

// ── CSV Import modal ─────────────────────────────────────────────────────────
function openImportModal(type) {
    const _base = (location.hostname === 'localhost' || /^\d+\.\d+\./.test(location.hostname))
        ? '/fortunett_technologies_' : '';
    const endpoints = {
        payments: _base + '/api/import/payments.php',
        clients:  _base + '/api/import/customers.php',
        packages: _base + '/api/import/packages.php',
    };
    const templates = {
        // The Safaricom statement's own column names are accepted verbatim, so an
        // ISP can export from the M-Pesa portal and upload it untouched. This
        // template mirrors those names rather than inventing a private format.
        payments: 'Receipt No.,Completion Time,Details,Paid In,Other Party Info,Account No.\nSGH4X2K9LM,2026-04-01 10:04:12,Funds received,500,254712345678 - JOHN DOE,ACC1042',
        clients:  'full_name,phone,email,address,username,package_name,connection_type,status,expiry_date\nJohn Doe,0712345678,john@example.com,,john.doe,Basic Hotspot,hotspot,active,2026-12-31',
        packages: 'name,type,price,download_speed,upload_speed,validity_value,validity_unit,data_limit,device_limit,description,status\nBasic Hotspot,hotspot,500,10,5,30,days,0,1,Entry level,active',
    };
    const titles = { payments: 'Import / Reconcile Payments', clients: 'Import Customers', packages: 'Import Packages' };
    const blurbs = {
        payments: 'Upload an M-Pesa statement export (or the template below). Matched payments are '
                + 'credited and the customer reconnected automatically; anything matching no customer '
                + 'is queued under Unclaimed Payments. Re-uploading an overlapping statement is safe — '
                + 'receipts already recorded are skipped.',
        clients: '', packages: ''
    };
    const blurbEl = document.getElementById('importModalBlurb');
    if (blurbEl) { blurbEl.textContent = blurbs[type] || ''; blurbEl.style.display = blurbs[type] ? 'block' : 'none'; }
    document.getElementById('importModalTitle').textContent  = titles[type] || 'Import CSV';
    document.getElementById('importModalForm').action        = endpoints[type];
    document.getElementById('importTemplateLink').href       = 'data:text/csv;charset=utf-8,' + encodeURIComponent(templates[type] || '');
    document.getElementById('importTemplateLink').download   = type + '_template.csv';
    document.getElementById('importModalResult').innerHTML   = '';
    document.getElementById('importCsvFile').value           = '';
    document.getElementById('importModal').style.display     = 'flex';
}
function closeImportModal() { document.getElementById('importModal').style.display = 'none'; }
function showImportResult(html, type) {
    const el = document.getElementById('importModalResult');
    el.style.cssText = 'display:block;padding:10px 14px;border-radius:8px;font-size:13px;margin-top:12px;'
        + (type === 'error'
            ? 'border:1px solid rgba(239,68,68,.3);background:rgba(239,68,68,.1);'
            : 'border:1px solid rgba(16,185,129,.3);background:rgba(16,185,129,.1);');
    el.innerHTML = html;
}
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('importModalForm');
    if (!form) return;
    form.addEventListener('submit', async function (e) {
        e.preventDefault();
        const file = document.getElementById('importCsvFile').files[0];
        if (!file) { showImportResult('Please select a CSV file.', 'error'); return; }
        const btn = document.getElementById('importSubmitBtn');
        btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Importing…';
        try {
            const fd = new FormData(); fd.append('csv_file', file);
            const res  = await fetch(form.action, { method: 'POST', body: fd });
            const data = await res.json();
            if (data.success) {
                let html = '<div style="color:#6ee7b7"><i class="fas fa-check-circle"></i> ' + (data.message || 'Done') + '</div>';
                if (data.errors && data.errors.length) {
                    html += '<div style="margin-top:8px;color:#fca5a5;font-size:12px"><strong>Errors:</strong><ul style="margin:4px 0 0 16px;padding:0">'
                        + data.errors.map(e => '<li>' + e + '</li>').join('') + '</ul></div>';
                }
                showImportResult(html, 'success');
                setTimeout(() => location.reload(), 2000);
            } else {
                showImportResult(data.message || 'Import failed.', 'error');
            }
        } catch { showImportResult('Connection error. Please try again.', 'error'); }
        finally { btn.disabled = false; btn.innerHTML = '<i class="fas fa-upload"></i> Import'; }
    });
    document.getElementById('importModal')?.addEventListener('click', function(e) {
        if (e.target === this) closeImportModal();
    });
});
</script>

<!-- ── Import CSV Modal ─────────────────────────────────────────────────────── -->
<div id="importModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:10000;align-items:center;justify-content:center;">
    <div style="background:#222221;border:1px solid rgba(255,255,255,.1);border-radius:14px;padding:28px 32px;width:100%;max-width:480px;box-shadow:0 20px 60px rgba(0,0,0,.6);">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
            <h3 id="importModalTitle" style="margin:0;color:#e2e2e0;font-size:18px;font-weight:600;">Import CSV</h3>
            <button onclick="closeImportModal()" style="background:none;border:none;color:rgba(255,255,255,.5);font-size:20px;cursor:pointer;line-height:1;">&times;</button>
        </div>
        <p id="importModalBlurb" style="display:none;margin:-10px 0 18px;font-size:12px;color:rgba(255,255,255,.42);line-height:1.6;"></p>
        <form id="importModalForm" method="post" enctype="multipart/form-data">
            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:13px;color:rgba(255,255,255,.55);margin-bottom:6px;">CSV File <span style="color:#fca5a5">*</span></label>
                <input id="importCsvFile" type="file" name="csv_file" accept=".csv,text/csv"
                    style="width:100%;padding:9px 12px;background:#1a1a19;border:1px solid rgba(255,255,255,.1);border-radius:8px;color:#e2e2e0;font-size:13px;box-sizing:border-box;">
            </div>
            <div style="margin-bottom:20px;font-size:13px;color:rgba(255,255,255,.4);">
                <i class="fas fa-info-circle" style="color:#93c5fd;margin-right:4px;"></i>
                First row must be the header row.
                <a id="importTemplateLink" href="#" download style="color:#93c5fd;text-decoration:none;margin-left:4px;">
                    <i class="fas fa-download"></i> Download template
                </a>
            </div>
            <div id="importModalResult" style="display:none;"></div>
            <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px;">
                <button type="button" onclick="closeImportModal()"
                    style="padding:9px 20px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);border-radius:8px;color:rgba(255,255,255,.7);font-size:14px;cursor:pointer;">
                    Cancel
                </button>
                <button id="importSubmitBtn" type="submit"
                    style="padding:9px 20px;background:linear-gradient(135deg,var(--primary-dark,#2C5282) 0%,var(--primary-color,#3B6EA5) 100%);border:none;border-radius:8px;color:#fff;font-size:14px;font-weight:600;cursor:pointer;">
                    <i class="fas fa-upload"></i> Import
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ── Unmatched Payments Modal ──────────────────────────────────────────────────
     Payments that reached the ISP but named nobody. The API behind this is
     tenant-scoped and already existed; there was simply no way for an ISP admin
     to reach it, so this money was only ever visible to FortuNett staff. -->
<div id="unmatchedModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);z-index:1100;align-items:flex-start;justify-content:center;padding:40px 16px 24px;box-sizing:border-box;overflow-y:auto;">
    <div style="background:#1e1e1d;border:1px solid rgba(255,255,255,.08);width:100%;max-width:680px;border-radius:16px;padding:26px;position:relative;box-shadow:0 32px 80px rgba(0,0,0,.85);margin:auto 0;">
        <button onclick="closeUnmatchedModal()" style="position:absolute;top:18px;right:18px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:50%;width:30px;height:30px;font-size:16px;cursor:pointer;color:rgba(255,255,255,.6);display:flex;align-items:center;justify-content:center;">&times;</button>
        <h3 style="font-size:16px;font-weight:700;color:#e2e2e0;margin:0 0 6px 0;display:flex;align-items:center;gap:10px;">
            <i class="fas fa-question-circle" style="color:#fcd34d;"></i> Unclaimed Payments
        </h3>
        <p style="font-size:12px;color:rgba(255,255,255,.4);margin:0 0 18px 0;line-height:1.6;">
            These payments arrived and were recorded, but the account reference matched no customer —
            common with Buy Goods tills, where the customer has nowhere to type an account number.
            Assigning one credits it and reconnects that customer immediately.
        </p>
        <div id="unmatchedBody"></div>
    </div>
</div>

<!-- ── Payment Status Modal ──────────────────────────────────────────────────── -->
<div id="payStatusModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);z-index:1100;align-items:center;justify-content:center;padding:16px;box-sizing:border-box;">
    <div style="background:#1e1e1d;border:1px solid rgba(255,255,255,.08);width:100%;max-width:440px;border-radius:16px;padding:28px 28px 24px;position:relative;box-shadow:0 32px 80px rgba(0,0,0,.85);">
        <button onclick="closePaymentStatus()" style="position:absolute;top:18px;right:18px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:50%;width:30px;height:30px;font-size:16px;cursor:pointer;color:rgba(255,255,255,.6);display:flex;align-items:center;justify-content:center;">&times;</button>
        <h3 style="font-size:16px;font-weight:700;color:#e2e2e0;margin:0 0 20px 0;display:flex;align-items:center;gap:10px;">
            <i class="fas fa-satellite-dish" style="color:var(--primary-light,#93c5fd);"></i> Payment Status
        </h3>
        <div id="payStatusContent"></div>
    </div>
</div>

<script>
// ── Three-dot dropdown ────────────────────────────────────────────────────────
function toggleDotMenu(btn) {
    const dropdown = btn.nextElementSibling;
    const isOpen = dropdown.classList.contains('open');
    closeDotMenus();
    if (!isOpen) {
        dropdown.classList.add('open');
        btn.style.background = 'var(--primary-color,#3B6EA5)';
        btn.style.color = '#fff';
    }
}
function closeDotMenus() {
    document.querySelectorAll('.dot-menu-dropdown.open').forEach(d => {
        d.classList.remove('open');
        const btn = d.previousElementSibling;
        if (btn) { btn.style.background = ''; btn.style.color = ''; }
    });
}
document.addEventListener('click', function(e) {
    if (!e.target.closest('.dot-menu-wrap')) closeDotMenus();
});

// ── Row filter tabs ───────────────────────────────────────────────────────────
// One tab bar, two independent dimensions: reconciliation status (did the money
// arrive) and settlement routing (whose account it is in). Only one filter is
// active at a time — picking a routing tab clears the status filter and back —
// because "Failed AND Awaiting disbursement" is an empty set by construction.
function applyTxFilter(key, value, tabEl) {
    document.querySelectorAll('.tx-tab').forEach(t => t.classList.remove('active'));
    tabEl.classList.add('active');
    document.querySelectorAll('.transactions-table tbody tr[data-status]').forEach(tr => {
        tr.style.display = (value === 'all' || tr.dataset[key] === value) ? '' : 'none';
    });
}
function filterTxRows(status, tabEl)  { applyTxFilter('status', status, tabEl); }
function filterTxRoute(routing, tabEl) { applyTxFilter('routing', routing, tabEl); }

// Count tabs on load
document.addEventListener('DOMContentLoaded', function() {
    const rows = document.querySelectorAll('.transactions-table tbody tr[data-status]');
    const counts = { completed: 0, pending: 0, failed: 0 };
    const routes = { direct: 0, awaiting: 0, disbursed: 0 };
    rows.forEach(r => {
        if (counts[r.dataset.status]  !== undefined) counts[r.dataset.status]++;
        if (routes[r.dataset.routing] !== undefined) routes[r.dataset.routing]++;
    });
    document.getElementById('tcCompleted').textContent = counts.completed;
    document.getElementById('tcPending').textContent   = counts.pending;
    document.getElementById('tcFailed').textContent    = counts.failed;
    document.getElementById('tcDirect').textContent    = routes.direct;
    document.getElementById('tcAwaiting').textContent  = routes.awaiting;
    document.getElementById('tcDisbursed').textContent = routes.disbursed;
});

// ── Auto-activation ───────────────────────────────────────────────────────────
// Registers this ISP's C2B URLs with Safaricom so payments made straight to
// their own paybill/till reconnect the customer without anyone touching it.
function turnOnAutoActivation(gatewayId, btn) {
    const original = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Registering...';
    fetch('api/payment/register_c2b.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gateway_id: gatewayId })
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            showToast(d.message || 'Auto-activation is now on.', 'success');
            setTimeout(() => location.reload(), 1200);
        } else {
            showToast(d.error || 'Could not register C2B.', 'error');
            btn.disabled = false;
            btn.innerHTML = original;
        }
    })
    .catch(() => {
        showToast('Network error registering C2B.', 'error');
        btn.disabled = false;
        btn.innerHTML = original;
    });
}

// ── Unclaimed payments ────────────────────────────────────────────────────────
function openUnmatchedModal() {
    document.getElementById('unmatchedModal').style.display = 'flex';
    loadUnmatched();
}
function closeUnmatchedModal() {
    document.getElementById('unmatchedModal').style.display = 'none';
}
document.getElementById('unmatchedModal')?.addEventListener('click', function (e) {
    if (e.target === this) closeUnmatchedModal();
});

function loadUnmatched() {
    const body = document.getElementById('unmatchedBody');
    body.innerHTML = '<div style="text-align:center;padding:26px;color:rgba(255,255,255,.4);"><i class="fas fa-spinner fa-spin"></i> Loading…</div>';

    const fd = new FormData();
    fd.append('action', 'list');
    fetch('api/payment/unmatched.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(d => {
            if (!d.success) {
                body.innerHTML = '<div style="color:#fca5a5;font-size:13px;">' + (d.error || 'Could not load.') + '</div>';
                return;
            }
            if (!d.payments.length) {
                body.innerHTML = '<div style="text-align:center;padding:26px;color:rgba(255,255,255,.4);font-size:13px;">'
                               + '<i class="fas fa-check-circle" style="color:#6ee7b7;font-size:26px;display:block;margin-bottom:10px;"></i>'
                               + 'Nothing unclaimed — every payment has been credited to a customer.</div>';
                return;
            }
            body.innerHTML = d.payments.map(renderUnmatchedRow).join('');
        })
        .catch(() => { body.innerHTML = '<div style="color:#fca5a5;font-size:13px;">Network error.</div>'; });
}

function renderUnmatchedRow(p) {
    const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
    const when = p.created_at ? p.created_at.substring(0, 16).replace('T', ' ') : '';

    const suggestions = (p.suggestions || []).length
        ? p.suggestions.map(s =>
            '<div class="um-sugg">'
          +   '<div style="min-width:0;">'
          +     '<div style="font-size:13px;color:#e2e2e0;font-weight:600;">' + esc(s.full_name || s.username) + '</div>'
          +     '<div style="font-size:11px;color:rgba(255,255,255,.35);">' + esc(s.phone || '') + ' · '
          +        esc(s.account_number || '') + ' · ' + esc(s.status || '') + '</div>'
          +   '</div>'
          +   '<button class="um-sugg-btn" onclick="resolveUnmatched(' + p.id + ',' + s.id + ',this)">Credit this customer</button>'
          + '</div>').join('')
        : '<div style="font-size:12px;color:rgba(255,255,255,.35);margin-top:8px;">'
        + 'No likely customer found. Record it manually with <strong>New Payment</strong>, then dismiss this.</div>';

    return '<div class="um-row" id="um-' + p.id + '">'
         +   '<div class="um-head">'
         +     '<span class="um-amt">KES ' + parseFloat(p.amount || 0).toLocaleString() + '</span>'
         +     '<button class="filter-btn" style="padding:4px 12px;font-size:12px;" onclick="ignoreUnmatched(' + p.id + ',this)">Dismiss</button>'
         +   '</div>'
         +   '<div class="um-meta">'
         +     'From <strong>' + esc(p.payer_name || p.phone || 'unknown') + '</strong>'
         +     (p.phone ? ' (' + esc(p.phone) + ')' : '')
         +     '<br>Reference typed: <code>' + esc(p.account_ref || '— none (till payment)') + '</code>'
         +     '<br>Receipt <code>' + esc(p.transaction_id) + '</code> · ' + esc(when)
         +     (p.unrouted ? '<br><span style="color:#fcd34d;">Could not be attributed to any ISP — confirm it is yours before crediting.</span>' : '')
         +   '</div>'
         +   suggestions
         + '</div>';
}

function resolveUnmatched(rowId, clientId, btn) {
    btn.disabled = true;
    btn.textContent = 'Crediting…';
    const fd = new FormData();
    fd.append('action', 'resolve');
    fd.append('id', rowId);
    fd.append('client_id', clientId);
    fetch('api/payment/unmatched.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                showToast(d.message || 'Payment credited and the customer reconnected.', 'success');
                document.getElementById('um-' + rowId)?.remove();
            } else {
                showToast(d.error || 'Could not credit this payment.', 'error');
                btn.disabled = false;
                btn.textContent = 'Credit this customer';
            }
        })
        .catch(() => {
            showToast('Network error.', 'error');
            btn.disabled = false;
            btn.textContent = 'Credit this customer';
        });
}

function ignoreUnmatched(rowId, btn) {
    btn.disabled = true;
    const fd = new FormData();
    fd.append('action', 'ignore');
    fd.append('id', rowId);
    fetch('api/payment/unmatched.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                document.getElementById('um-' + rowId)?.remove();
            } else {
                showToast(d.error || 'Could not dismiss.', 'error');
                btn.disabled = false;
            }
        })
        .catch(() => { showToast('Network error.', 'error'); btn.disabled = false; });
}

// ── Payment Status modal ──────────────────────────────────────────────────────
function openPaymentStatus(tx) {
    const modal   = document.getElementById('payStatusModal');
    const content = document.getElementById('payStatusContent');
    const status  = tx.status || 'pending';
    const method  = (tx.payment_method || '').toLowerCase();
    const mpesaCode = String(tx.mpesa_result_code ?? '');
    const collType  = tx.collection_type || null;

    // Effective status (mirrors PHP badge logic)
    let eff = status;
    if (status !== 'completed') {
        if (mpesaCode === '1032') eff = 'cancelled';
        else if (mpesaCode === '1037') eff = 'timeout';
        else if (mpesaCode && mpesaCode !== '0') eff = 'failed';
    }

    // Delivery text
    let deliveryIcon, deliveryColor, deliveryText, deliverySub;
    if (!method.startsWith('mpesa')) {
        deliveryIcon  = 'fa-money-bill-wave';
        deliveryColor = '#93c5fd';
        deliveryText  = 'Cash / Manual';
        deliverySub   = 'Manually recorded — no M-Pesa settlement applies.';
    } else if (eff === 'completed') {
        deliveryIcon  = 'fa-check-circle';
        deliveryColor = '#6ee7b7';
        deliveryText  = 'Delivered';
        // Distinguish held from already-remitted. Saying "settlement is on the
        // next cycle" for money that was disbursed weeks ago makes the ISP chase
        // a payout they have already received.
        deliverySub   = collType === 'platform'
            ? (tx.released_at
                ? 'Collected by the FortuNett till and settled through payout or deduction on ' + tx.released_at.substring(0, 10) + '.'
                : 'Collected by the FortuNett shared till — awaiting disbursement to your account.')
            : 'Paid straight into your own M-Pesa account. Nothing is owed to you for this one.';
    } else if (eff === 'cancelled') {
        deliveryIcon  = 'fa-times-circle';
        deliveryColor = '#fca5a5';
        deliveryText  = 'Cancelled';
        deliverySub   = 'Customer cancelled the M-Pesa prompt. No funds moved.';
    } else if (eff === 'timeout') {
        deliveryIcon  = 'fa-clock';
        deliveryColor = '#fca5a5';
        deliveryText  = 'Timed Out';
        deliverySub   = 'No response from the phone within 60 seconds. No funds moved.';
    } else if (eff === 'failed') {
        deliveryIcon  = 'fa-exclamation-circle';
        deliveryColor = '#fca5a5';
        deliveryText  = 'Failed';
        deliverySub   = 'M-Pesa returned an error. No funds moved.';
    } else {
        deliveryIcon  = 'fa-spinner fa-spin';
        deliveryColor = '#fcd34d';
        deliveryText  = 'Processing';
        deliverySub   = 'Awaiting M-Pesa callback — funds have not been confirmed yet.';
    }

    const paybillLine = (method === 'mpesa')
        ? `<div style="display:flex;justify-content:space-between;margin-bottom:10px;font-size:13px;">
               <span style="color:rgba(255,255,255,.45);">Collected by</span>
               <span style="font-weight:600;color:#e2e2e0;">${collType === 'platform' ? 'FortuNett shared till' : (collType === 'direct' ? 'Your own paybill / till' : 'M-Pesa')}</span>
           </div>`
        : '';

    const receiptLine = (tx.transaction_id && !tx.transaction_id.startsWith('ws_'))
        ? `<div style="display:flex;justify-content:space-between;margin-bottom:10px;font-size:13px;">
               <span style="color:rgba(255,255,255,.45);">Receipt / Ref</span>
               <span style="font-weight:600;color:#e2e2e0;font-family:monospace;">${tx.transaction_id}</span>
           </div>`
        : '';

    const mpesaCodeLine = mpesaCode
        ? `<div style="display:flex;justify-content:space-between;margin-bottom:10px;font-size:13px;">
               <span style="color:rgba(255,255,255,.45);">M-Pesa Code</span>
               <span style="font-weight:600;color:#e2e2e0;font-family:monospace;">${mpesaCode}</span>
           </div>`
        : '';

    content.innerHTML = `
        <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:18px 20px;margin-bottom:18px;text-align:center;">
            <i class="fas ${deliveryIcon}" style="font-size:32px;color:${deliveryColor};margin-bottom:10px;display:block;"></i>
            <div style="font-size:18px;font-weight:700;color:${deliveryColor};margin-bottom:6px;">${deliveryText}</div>
            <div style="font-size:12px;color:rgba(255,255,255,.45);line-height:1.5;">${deliverySub}</div>
        </div>
        <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:10px;padding:14px 16px;">
            <div style="display:flex;justify-content:space-between;margin-bottom:10px;font-size:13px;">
                <span style="color:rgba(255,255,255,.45);">Customer</span>
                <span style="font-weight:600;color:#e2e2e0;">${tx.full_name || 'Unknown'}</span>
            </div>
            <div style="display:flex;justify-content:space-between;margin-bottom:10px;font-size:13px;">
                <span style="color:rgba(255,255,255,.45);">Amount</span>
                <span style="font-weight:700;color:#fff;">KES ${parseFloat(tx.amount||0).toLocaleString()}</span>
            </div>
            ${paybillLine}
            ${receiptLine}
            ${mpesaCodeLine}
        </div>
    `;

    modal.style.display = 'flex';
}
function closePaymentStatus() {
    document.getElementById('payStatusModal').style.display = 'none';
}
document.getElementById('payStatusModal').addEventListener('click', function(e) {
    if (e.target === this) closePaymentStatus();
});
</script>

<?php include 'includes/footer.php'; ?>
