<?php
require_once __DIR__ . '/includes/db_master.php';
require_once __DIR__ . '/includes/email_helper.php';

$error = '';
$success = '';

// Get business name
$business_name = 'FortuNett Technologies';
try {
    $stmt = $pdo->query("SELECT business_name FROM isp_profile LIMIT 1");
    $profile = $stmt->fetch();
    if ($profile && !empty($profile['business_name'])) {
        $business_name = $profile['business_name'];
    }
} catch (Exception $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);

    if ($email === '') {
        $error = 'Please enter your email address.';
    } else {
        try {
            // Check if user exists
             $stmt = $pdo->prepare("SELECT id, username FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if (!$user) {
                $error = "No account found with that email.";
            } else {
                // Generate token & expiry
                $token = bin2hex(random_bytes(32));
                $expiry = date('Y-m-d H:i:s', strtotime('+30 minutes'));

                // Save to DB
                $update = $pdo->prepare("
                    UPDATE users
                    SET reset_token = ?, reset_token_expiry = ?
                    WHERE id = ?
                ");
                $update->execute([$token, $expiry, $user['id']]);

                // Send email
                $resetLink = "https://" . $_SERVER['HTTP_HOST'] . "/reset_password.php?token=" . $token;
                $subject = "Reset Your Password - $business_name";
                $body=fortunettEmail('Reset your password',
                    '<p>Hello <strong>'.fortunettEmailEscape($user['username']).'</strong>,</p><p>We received a request to reset your password. Use the button below to choose a new one.</p>'
                    .fortunettEmailSummary(['Link expires'=>'30 minutes'])
                    .'<p style="font-size:13px;color:#64748b;">If you did not request this, you can ignore this email. Your password stays unchanged.</p>',
                    ['category'=>'Account security','preheader'=>'Choose a new password. This link expires in 30 minutes.','action_label'=>'Reset password','action_url'=>$resetLink]);

                if (function_exists('sendEmail') && sendEmail($email, $subject, $body) === true) {
                    $success = "A password reset link has been sent to your email.";
                } else {
                    $error = "Failed to send reset email. Please try again later.";
                }
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password — <?php echo htmlspecialchars($business_name); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/auth.css?v=3">
<link rel="stylesheet" href="/css/responsive-app.css?v=1">
<script src="/js/responsive-app.js?v=1" defer></script>
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-header">
            <div class="auth-icon-wrap">
                <i class="fas fa-key"></i>
            </div>
            <h1><?php echo htmlspecialchars($business_name); ?></h1>
            <p>Account Recovery</p>
        </div>

        <div class="auth-body">
            <div class="auth-subtitle">
                <h2>Forgot Password?</h2>
                <p>Enter your email to receive a reset link</p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-paper-plane"></i>
                    <span><?php echo htmlspecialchars($success); ?></span>
                </div>
                <div class="auth-link">
                    <a href="login.php">&larr; Back to Login</a>
                </div>
            <?php else: ?>
                <form method="POST">
                    <div class="form-group">
                        <label>Email Address <span class="required">*</span></label>
                        <input type="email" name="email" class="form-control-auth" required
                               placeholder="Enter your email"
                               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    </div>

                    <button type="submit" class="btn-auth">
                        <span>Send Reset Link</span>
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </form>

                <div class="auth-link">
                    Remembered it? <a href="login.php">Sign in here</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
